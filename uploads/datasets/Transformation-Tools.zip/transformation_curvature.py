# Author: Ovidiu Csillik
# Aim: Transformation (normalization) of profile or plan curvature frequency
# distributions towards that of the Gaussian model. Arctangent transformation
# is used, based on Evans(1984) formula

import arcpy
import os, sys, math, string
import numpy
from arcpy import env  
from arcpy.sa import *

inCurvature = arcpy.GetParameterAsText(0)
outCurvature = arcpy.GetParameterAsText(1)

work = arcpy.GetParameterAsText(2)
arcpy.env.overwriteOutput = True
env.workspace = work

arcpy.RasterToASCII_conversion(inCurvature, "curvature_ascii.txt")
f = open(work+"\curvature_ascii.txt", 'r')
header1 = f.readline()
header2 = f.readline()
header3 = f.readline()
header4 = f.readline()
header5 = f.readline()
header6 = f.readline()
lista=[]
for line in f:
    line = line.strip()
    columns = line.split()
    for i in range(0, len(columns)):
        j = float(columns[i])
        if j != -9999:
            lista.append(j)

lista = numpy.asarray(lista)
f.close()

def kurtosis(data):
    n = 0
    mean = 0
    M2 = 0
    M3 = 0
    M4 = 0
 
    for x in data:
        n1 = n
        n = n + 1
        delta = x - mean
        delta_n = delta / n
        delta_n2 = delta_n * delta_n
        term1 = delta * delta_n * n1
        mean = mean + delta_n
        M4 = M4 + term1 * delta_n2 * (n*n - 3*n + 3) + 6 * delta_n2 * M2 - 4 * delta_n * M3
        M3 = M3 + term1 * delta_n * (n - 2) - 3 * delta_n * M2
        M2 = M2 + term1
 
    kurtosis = (n*M4) / (M2*M2) - 3
    #skewness = (math.sqrt(n)*M3) / (M2**1.5)
    return kurtosis

path = work+"\\results_curvature.txt"
results = open(path, 'w')

k = 0.1
multp = [i * k for i in lista]
actg = [math.atan(j) for j in multp]
kurto1 = kurtosis(actg)
if kurto1 < 0:
    kurto1 = -1 * kurto1
kurto2 = kurto1

results.write("k = %s, kurtosis = %s\n" %(k,kurto1))
k = 0.2
while kurto1 >= kurto2:
    k_fin = k
    kurto1 = kurto2
    multp = [i * k for i in lista]
    actg = [math.atan(j) for j in multp]
    kurto2 = kurtosis(actg)
    if kurto2 < 0:
        kurto2 = -1 * kurto2
    k = k + 0.1
    results.write("k = %s, kurtosis = %s\n" %(k_fin,kurto2))

# Applying atan with k detected, to inCurvature
k_final=k_fin-1
inCurvatureK = Raster(inCurvature)*k_final
outCurvTan = ATan(inCurvatureK)

outCurvTan.save(outCurvature)
