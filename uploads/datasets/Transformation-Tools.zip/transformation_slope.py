# Author: Ovidiu Csillik
# Aim: Transformation (normalization) of slope gradient frequency
# distribution towards that of the Gaussian model. Box-Cox transformation is used.

import arcpy
import os, sys, math, string
import numpy
from arcpy import env  
from arcpy.sa import *

inSlope = arcpy.GetParameterAsText(0)
outSlope = arcpy.GetParameterAsText(1)

work = arcpy.GetParameterAsText(2)
arcpy.env.overwriteOutput = True
env.workspace = work

arcpy.RasterToASCII_conversion(inSlope, "slope_ascii.txt")
f = open(work+"\slope_ascii.txt", 'r')
header1 = f.readline()
header2 = f.readline()
header3 = f.readline()
header4 = f.readline()
header5 = f.readline()
header6 = f.readline()
lista=[]
for line in f:
    line = line.strip()
    columns = line.split()
    for i in range(0, len(columns)):
        j = float(columns[i])
        if j != -9999:
            lista.append(j)

lista = numpy.asarray(lista)
f.close()

def skew(data):
    n = 0
    mean = 0
    M2 = 0
    M3 = 0
    M4 = 0
    for x in data:
        n1 = n
        n = n + 1
        delta = x - mean
        delta_n = delta / n
        delta_n2 = delta_n * delta_n
        term1 = delta * delta_n * n1
        mean = mean + delta_n
        M4 = M4 + term1 * delta_n2 * (n*n - 3*n + 3) + 6 * delta_n2 * M2 - 4 * delta_n * M3
        M3 = M3 + term1 * delta_n * (n - 2) - 3 * delta_n * M2
        M2 = M2 + term1
    #kurtosis = (n*M4) / (M2*M2) - 3
    skewness = (math.sqrt(n)*M3) / (M2**1.5)
    return skewness

path = work+"\\results_slope.txt"
results = open(path, 'w')
#print "Skewness lambda 1 = ", skew(lista)

def negative(sk):
    if sk < 0:
        sk = -1 * sk
    return sk

skew_1 = skew(lista)
skew_1 = negative(skew_1)
skew_2 = skew(lista**2)
skew_2 = negative(skew_2)

# Comparare skewness pentru lambda 1 si 2
if skew_1 < skew_2:
    skew_05 = skew(lista**0.5)
    skew_05 = negative(skew_05)
    # Comparare skewness pentru lambda 0.5 si 1
    if skew_05 > skew_1:
        skew_final = skew_1
        lista_new = lista
        ###print "Skewness 1 este: ", skew(lista_new)
        results.write("lambda = 1, skewness = %s\n" %skew(lista_new))
        outSlopeTransf = Raster(inSlope)
        outSlopeTransf.save(outSlope)
    else:
        # Caz special in care log intre 0 si 1 nu merge. Se adauga valoare, astfel incat sa porneasca lista de la 1 --> lista2
        min_orig = min(lista)
        max_orig = max(lista)
        #print "Lista normala: ", lista
        #print "Min este: ", min(lista)
        if min(lista)<1:
            lista2 = lista + (1-min(lista))
        #print "Noul min este: ", min(lista2)

        #print "Lista smechera: ", lista2        
        skew_log = skew(numpy.log(lista2))        # lista2, unde minimul este 1
        skew_log = negative(skew_log)
        # Comparare skewness pentru lambda 0 si 0.5
        if skew_log > skew_05:
            skew_final = skew_05     
            lista_new = lista**0.5
            #print "Skewness 0.5 este: ", skew(lista_new)
            results.write("lambda = 0.5, skewness = %s\n" %skew(lista_new))
            outSlopeTransf = SquareRoot(Raster(inSlope))
            outSlopeTransf.save(outSlope)
        else:
            skew_m05 = skew(1/(lista2**0.5))
            skew_m05 = negative(skew_m05)
            # Comparare skewness pentru lambda -0.5 si 0
            if skew_m05 > skew_log:
                skew_final = skew_log
                lista_new = numpy.log(lista2)       # lista2, unde minimul este 1
                #print "Skewness 0 este: ", skew(lista_new)
                results.write("lambda = 0, skewness = %s\n" %skew(lista_new))
                outSlopeTransf = Ln(Raster(inSlope))
                outSlopeTransf.save(outSlope)
            else:
                skew_m1 = skew(1/lista2)
                skew_m1 = negative(skew_m1)
                # Comparare skewness pentru lambda -1 si -0.5
                if skew_m1 > skew_m05:
                    skew_final = skew_m05
                    lista_new = 1/(lista2**0.5)
                    #print "Skewness -0.5 este: ", skew(lista_new)
                    results.write("lambda = -0.5, skewness = %s\n" %skew(lista_new))
                    outPart1 = SquareRoot(Raster(inSlope))
                    outSlopeTransf = Divide(1, outPart1)
                    outSlopeTransf.save(outSlope)
                else:
                    skew_m2 = skew(1/(lista2**2))
                    skew_m2 = negative(skew_m2)
                    # Comparare skewness pentru lambda -2 si -1
                    if skew_m2 > skew_m1:
                        skew_final = skew_m1
                        lista_new = 1/lista2
                        #print "Skewness -1 este: ", skew(lista_new)
                        results.write("lambda = -1, skewness = %s\n" %skew(lista_new))
                        outSlopeTransf = 1/(Raster(inSlope))
                        outSlopeTransf.save(outSlope)
                    else:
                        skew_m3 = skew(1/(lista2**3))
                        skew_m3 = negative(skew_m3)
                        # Comparare skewness pentru lambda -3 si -2
                        if skew_m3 > skew_m2:
                            skew_final = skew_m2
                            lista_new = 1/(lista2**2)
                            #print "Skewness -2 este: ", skew(lista_new)
                            results.write("lambda = -2, skewness = %s\n" %skew(lista_new))
                            outSlopeTransf = 1/(Power(Raster(inSlope), 2))
                            outSlopeTransf.save(outSlope)
                        else:
                            skew_m4 = skew(1/(lista2**4))
                            skew_m4 = negative(skew_m4)
                            # Comparare skewness pentru lambda -4 si -3
                            if skew_m4 > skew_m3:
                                skew_final = skew_m3
                                lista_new = 1/(lista2**3)
                                #print "Skewness -3 este: ", skew(lista_new)
                                results.write("lambda = -3, skewness = %s\n" %skew(lista_new))
                                outSlopeTransf = 1/(Power(Raster(inSlope), 3))
                                outSlopeTransf.save(outSlope)
                            else:
                                skew_final = skew_m4
                                lista_new = 1/(lista2**4)
                                #print "Skewness -4 este: ", skew(lista_new)
                                results.write("lambda = -4, skewness = %s\n" %skew(lista_new))
                                outSlopeTransf = 1/(Power(Raster(inSlope), 4))
                                outSlopeTransf.save(outSlope)
else:
    skew_3 = skew(lista**3)
    skew_3 = negative(skew_3)
    # Comparare skewness pentru lambda 2 si 3
    if skew_2 < skew_3:
        skew_final = skew_2
        lista_new = lista**2
        #print "Skewness 2 este: ", skew(lista_new)
        results.write("lambda = 2, skewness = %s\n" %skew(lista_new))
        outSlopeTransf = Power(Raster(inSlope), 2)
        outSlopeTransf.save(outSlope)
    else:
        skew_4 = skew(lista**4)
        skew_4 = negative(skew_4)
        # Comparare skewness pentru lambda 3 si 4
        if skew_3 < skew_4:
            skew_final = skew_3
            lista_new = lista**3
            #print "Skewness 3 este: ", skew(lista_new)
            results.write("lambda = 3, skewness = %s\n" %skew(lista_new))
            outSlopeTransf = Power(Raster(inSlope), 3)
            outSlopeTransf.save(outSlope)
        else:
            skew_5 = skew(lista**5)
            skew_5 = negative(skew_5)
            # Comparare skewness pentru lambda 4 si 5
            if skew_4 < skew_5:
                skew_final = skew_4
                lista_new = lista**4
                #print "Skewness 4 este: ", skew(lista_new)
                results.write("lambda = 4, skewness = %s\n" %skew(lista_new))
                outSlopeTransf = Power(Raster(inSlope), 4)
                outSlopeTransf.save(outSlope)

