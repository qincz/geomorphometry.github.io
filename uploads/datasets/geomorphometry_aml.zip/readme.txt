/* set amlpath to your directory
/* &amlpath <your aml dir>
/* set your workspace 
w <your workspace with dem data> 
/* make sure that DEM is in metric system and not geographic coordinates
/* RECOMMENDATION: dem names longer than ONE charachter and shorter/equal than 4 charachter
elevation residual analyis
&r elevres <dem> <cellsize>
&r topo <dem> <stream treshold>

/* quality checking on your dem
/* check your watersheds - all there or empty spaces ? 
/* fill and filter might help to clear noise and artifical sinks
fill <dem> <outdem> SINK z_fill_limit (e.g. for srtm data use a value of 20) 
filter <dem> <outdem> low
/* spikefinder - finds unusal elevation differences compared to the surrounding
&r thrfilter thr* static 5


/* just to recompute watershed related parameter..
&r topo_wshd <dem> <stream treshold>
/* monte carlo simulation of TWI
/* Usage: MONTEWI <dem> <out-grid> <stdev> <n steps> {break}
&r montewi a a_mwi 16 50 0.001

/* rescalegrids with ZSCALE or based on maximum .. default ztrans
&r rescalegrids cgrid* {ZTRANS|SCALE}


/* simplelf after canadian soil landscape classification manual
&r simplelfabc1 alf a_simplela a

/* Pennocks lf classification
&r pennock95 alf alf_pen11

/* parks lf classification
&r lfpark alf

/* Iwahasis lf classification
3 parameter scale classification signature
&r act_hir alf alt16 $amlpath/laplacian.ker 16

/* meybecks lf classification



/* Openness according to Yokoyama 2002

&r openness <dem> <diam1 5> {diam2 10}

/* ruggedness

USAGE: &r ruggedness <dem>
&r ruggedness alf

/* landformshape
&r landformshape alf alf_mcnab MCNAB

/* entropy

    
&r entropy alf 20

/* landslide
 