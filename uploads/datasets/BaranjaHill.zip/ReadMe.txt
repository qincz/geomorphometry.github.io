
Case study "Baranja Hill"

DATASETS:


DEM25m - 25 m resolution DEM derived from the 1:5K contours (ArcInfo ASCI grid format)
contours.zip - Contour lines digitized from the 1:50K topo maps (ESRI Shapefile)
contours5K.zip - Contour lines digitized from the 1:5K topo maps (ESRI Shapefile) 
wstreams.zip - Streams and water bodies digitized from the 1:50K topo maps (ESRI Shapefile)
elevations.zip - very precise elevation measurements from 1:5K land survey (ESRI Shapefile)
DEM25srtm - 25 m resolution DEM from SRTM 2000 project ordered via http://eoweb.dlr.de (ArcInfo ASCI grid format)
orthophoto.zip - 5 m resolution ortophoto (ArcInfo ASCI grid format)
topo5K.zip - Topo map 1:5000 (geotif, 23 MB!!!)
satimage.zip - 25 m resolution Landsat 7 image from September 1999 (ERDAS .lan format)
landcover.zip - Land cover map digitized from the ortophoto (ESRI Shapefile)
geoform.zip - Map of the geoforms using the geopedological approach (ESRI Shapefile)

LINEAGE: 
50K and 5K scale topomaps and aerial photo have been obtained from the Croatian State Geodetic Department (http://www.dgu.hr). Orthorectified photo was produced following the methodology explained in Rossiter & Hengl (2002). From the orthophoto we digitized on-screen land cover polygon map. From the stereo-pairs we interpreted the generic landforms and then created a polygon map of geoforms (see also Rossiter & Hengl (2002)). From topomaps, we extracted contours and streams and water bodies. In the case of 1:50K the equidistance was 20 m in hilland and 5 m in plain, and for the 1:5K the equidistance was 5 m in hilland and 1 m in plain. From the 1:5K contours and geodetic points, the 5 m DEM has been derived using the ANUDEM (topogrid) procedure in ArcInfo and then resampled to the 25 m gird. The 30 m SRTM DEM (15'x15' block) was ordered from the German Aerospace Agency (http://eoweb.dlr.de), then resampled to the 25 grid so it can be compared with the DEM25m. IMPORTANT NOTE: According to a licence agreement, the SRTM dataset can not be distributed or used for commercial purposes outside this project.

References:
Hutchinson, M.F., 1989. A new procedure for gridding elevation and stream line data with automatic removal of spurious pits. Journal of Hydrology, 106: 211-232.
Rossiter D.G., Hengl T. 2002 Creating geometrically-correct photo-interpretations, photomosaics, and base maps for a project GIS. Technical notes, International Institute for Geo-information Science and Earth Observation (ITC), Enschede, pp. 21.


BOUNDING COORDINATES:

(a) 25 m

ncols 147
nrows 149
xllcorner 6551884
yllcorner 5070562
cellsize 25.00

(b) 5 m

ncols 730
nrows 741
xllcorner 6551894.5
yllcorner 5070569.5
cellsize 5.00


COORDINATE SYSTEM:

Coordinate system "Zone 6"

- Definition of the prj file:
PROJCS["Croatia",GEOGCS["GCS_Croatia_2000",DATUM["D_Croatia_2000",SPHEROID["Bessel_1841",6377397.155,299.15281]],PRIMEM["Greenwich",0],UNIT["Degree",0.017453292519943295]],PROJECTION["Transverse_Mercator"],PARAMETER["False_Easting",6500000],PARAMETER["False_Northing",0],PARAMETER["Central_Meridian",18],PARAMETER["Scale_Factor",0.9999],PARAMETER["Latitude_Of_Origin",0],UNIT["Meter",1]]

- Definition of the D_Croatia_2000 datum file:
DATUM: D_Croatia_2000, SPHEROIDID: 7004.00000, SPHEROID: Bessel_1841, A: 6377397.15500, INVERSE_F: 299.15281, GEOGTRANID: 8378.00000, METHODID: 9606.00000, METHOD: Position_Vector, DX: 682.00000, DY: -203.00000, DZ: 480.00000,