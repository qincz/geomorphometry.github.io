
MAPSET nc_coast_demseries
includes DEMs 1974-2008 and orthophotos 1932-2009 at 1m resolution 
for the Jockey's Ridge State park and town of Nags Head on Outer Banks, North Carolina.
The coordinate system is NC State Plane in meters (EPSG 3358).
To work with this data set, unzip it into the nc_spm_08 directory
(nc_coast_demseries directory should be at the same level as PERMANENT folder)

Spatial extent is defined by region files and indicated by the name of the raster:
JR_NH: Jockey's ridge area from ocean to sound
NH: smaller area from ocean to eastmost dune of JR, covered by more lidar surveys 
JR: JR dunes only, east of highway, older data

Time is indicated in the file name as YYYYMMDD and by r.timestamp

Vector data include
- JR peaks 1950-2008, JR_NH region area and historical shorelines

Notes
- the two oldest DEMs were extrapolated beyond the available data,
visible rectangles indicate where the data were not available -
do not use these DEMs for analysis for elevations below 6m.
- rasters are substantially smoothed, to keep the new data consistent 
with the older data in terms of detail.
To get more better representation of structures from lidar surveys,
re-interpolate to 0.3-0.5m resolution with v.surf.rst or v.surf.bspline
using the available external point clouds nc_coast_pointseries.zip
available at
http://courses.ncsu.edu/mea792/common/media/nc_coast_pointseries.zip

