/*****************************************************************************
FlowTools flow visualization tools for SEXTANTE algorithm library.
Copyright (C) 2009 Daniel Nüst

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

For more information, contact: daniel.nuest@gmail.com

 *****************************************************************************/
package de.ifgi.sextante.flowTools.flowmap;

import java.awt.geom.Point2D;

import org.apache.log4j.Logger;

import edu.stanford.hci.flowmap.layout.MapProjection;

/**
 * 
 * Changes to {@link MapProjection}: Added inverse projection for Mercator.
 * 
 * @author Daniel Nüst (daniel.nuest@gmail.com)
 * 
 */
public class MyMapProjection extends MapProjection {

	private static final double MERCARTOR_Y_AXIS_LON = 0.0d;

	/**
	 * http://mathworld.wolfram.com/MercatorProjection.html It's important that
	 * this returns a new Point (see NodeLayout)
	 * 
	 * @param latitude
	 * @param longitude
	 * @return x,y values of this latitude and longitude
	 */
	public static Point2D mercatorProjection(double latitude, double longitude) {
		double tempLat = latitude * Math.PI / 180;
		double yVal = Math.log(Math.tan(tempLat) + (1 / Math.cos(tempLat))); // 1/cos(x)
		// =
		// sec(x)
		return new Point2D.Double(longitude - MERCARTOR_Y_AXIS_LON, yVal);
	}

	/**
	 * Returns array containing longintude and latitude.
	 * 
	 * See: http://mathworld.wolfram.com/MercatorProjection.html and
	 * http://en.wikipedia.org/wiki/Mercator_projection
	 * 
	 * @return lon, lat
	 */
	public static double[] inverseMercartorProjection(double latitude,
			double longitude) {
		double lat = Math.atan(Math.sinh(latitude)) * 180 / Math.PI;
		double lon = longitude + MERCARTOR_Y_AXIS_LON;
		return new double[] { lon, lat };
	}

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Logger logger = Logger.getLogger(MyMapProjection.class);

		double lat = 51.96251;
		double lon = 7.625901;
		logger.info(lat + ", " + lon);
		Point2D p1 = mercatorProjection(lat, lon);
		logger.info(p1);

		double[] latLon = inverseMercartorProjection(p1.getX(), p1.getY());
		logger.info(latLon[0] + ", " + latLon[1]);
	}

}
