/*****************************************************************************
FlowTools flow visualization tools for SEXTANTE algorithm library.
Copyright (C) 2009 Daniel Nüst

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

For more information, contact: daniel.nuest@gmail.com

 *****************************************************************************/
package de.ifgi.sextante.flowTools.flowmap;

import org.apache.log4j.Logger;

import com.vividsolutions.jts.geom.Coordinate;

import edu.stanford.hci.flowmap.db.ColumnSchema;
import edu.stanford.hci.flowmap.db.QueryRecord;
import edu.stanford.hci.flowmap.db.QueryRow;
import edu.stanford.hci.flowmap.db.RowSchema;
import edu.stanford.hci.flowmap.layout.PositionLayout;
import edu.stanford.hci.flowmap.model.Globals;
import edu.stanford.hci.flowmap.model.Globals.ProgramType;
import es.unex.sextante.core.Sextante;
import es.unex.sextante.dataObjects.IFeature;
import es.unex.sextante.dataObjects.IFeatureIterator;
import es.unex.sextante.dataObjects.IVectorLayer;
import es.unex.sextante.exceptions.GeoAlgorithmExecutionException;
import es.unex.sextante.exceptions.IteratorException;
import es.unex.sextante.parameters.Parameter;

/**
 * 
 * Class provides a data model for Flow Map Layout based on two shape files.
 * First, a shape file containing only one point - the source of the flow.
 * Second, a shape file containig all destinations of the flow.
 * 
 * @author Daniel Nüst (daniel.nuest@gmail.com)
 * 
 */
public class ShapefilesQueryRecord extends QueryRecord {

	private static final long serialVersionUID = 4867725115618557412L;
	
	private static Logger logger = Logger.getLogger(ShapefilesQueryRecord.class);

	public static final String COLUMN_NAME = "Name";
	public static final String COLUMN_X = "X";
	public static final String COLUMN_Y = "Y";
	public static final String COLUMN_VALUE = "Value";

	private RowSchema shapefilesRowSchema;
	private PositionLayout posLayout;

	private boolean initialized = false;

	/**
	 * 
	 * @param srcLayer
	 *            is a layer containig only one point, the source
	 * @param idSrcParam
	 *            gives the identification field in the source layer
	 * @param destinationLayer
	 *            is a layer containing destination points with a flow size
	 * @param idDestParam
	 *            gives the identification field in the destination layer
	 * @param flowInputParam
	 *            gives the flow size field in the destination layer
	 */
	public ShapefilesQueryRecord(IVectorLayer srcLayer, Parameter idSrcParam,
			IVectorLayer destinationLayer, Parameter idDestParam,
			Parameter flowInputParam) {
		logger.info("Creating ShapefilesQueryRecord from " + srcLayer + " and " + destinationLayer);

		this.posLayout = new MyGeographicPositionLayout();
		
		Globals.currentType = ProgramType.INTERACTIVE;
		Globals.runNodeEdgeRouting = true;
		// Globals.runNodeEdgeRouting = false;

		// Globals.useLayoutAdjustment = true;
		Globals.useLayoutAdjustment = false;

		// create the row schema
		this.shapefilesRowSchema = new RowSchema();
		String columnNames[] = { COLUMN_NAME, COLUMN_X, COLUMN_Y, COLUMN_VALUE };
		int columnTypes[] = { ColumnSchema.STRING, ColumnSchema.NUMBER,
				ColumnSchema.NUMBER, ColumnSchema.NUMBER };
		for (int i = 0; i < 4; i++) {
			this.shapefilesRowSchema.addSchema(columnNames[i], columnTypes[i]);

			// tell the position layout to setup the mapping between columns
			// we use i+1 because in sql the index starts at 1, not 0.
			this.posLayout.setColumnMapping(i + 1, columnNames[i],
					this.shapefilesRowSchema);
		}

		// must set the row schema first for the query record
		this.setRowSchema(this.shapefilesRowSchema);
		// the row schema must know about the position layout
		this.shapefilesRowSchema.setPositionLayout(this.posLayout);

		// source
		IFeature srcFeature;
		try {
			srcFeature = srcLayer.iterator().next();
			Coordinate srcCoord = srcFeature.getGeometry().getCoordinate();
			String srcName = srcFeature.getRecord().getValue(
					idSrcParam.getParameterValueAsInt()).toString();
			
			QueryRow srcRow = new QueryRow(this.shapefilesRowSchema, this.getId());
			srcRow.setInfo(this.shapefilesRowSchema.getDefaultNameId(), srcName);
			srcRow.setInfo(this.shapefilesRowSchema.getDefaultX(), Double
					.valueOf(srcCoord.x));
			srcRow.setInfo(this.shapefilesRowSchema.getDefaultY(), Double
					.valueOf(srcCoord.y));
			srcRow.setInfo(this.shapefilesRowSchema.getDefaultValueId(), Double.valueOf(0.0d));
			this.setSourceRow(srcRow);
			
			logger.info("Added source row:	" + srcRow);
			
			// destinations
			IFeatureIterator iter = destinationLayer.iterator();
			while (iter.hasNext()) {
				IFeature feature = iter.next();
				Coordinate destCoord = feature.getGeometry().getCoordinate();
				String destName = feature.getRecord().getValue(
						idDestParam.getParameterValueAsInt()).toString();
				Object flowSize = feature.getRecord().getValue(
						flowInputParam.getParameterValueAsInt());

				double value = Double.MIN_VALUE;
				if (flowSize instanceof Number) {
					Number flow = (Number) flowSize;
					value = flow.doubleValue();
				} else if (flowSize instanceof String) {
					String flow = (String) flowSize;
					value = Double.parseDouble(flow);
				}
				
				// assume the next thing we see are destination nodes
				QueryRow destRow = new QueryRow(this.shapefilesRowSchema, this
						.getId());
				this.addFlowRow(destRow);

				destRow.setInfo(this.shapefilesRowSchema.getDefaultNameId(),
						destName);
				destRow.setInfo(this.shapefilesRowSchema.getDefaultX(), Double
						.valueOf(destCoord.x));
				destRow.setInfo(this.shapefilesRowSchema.getDefaultY(), Double
						.valueOf(destCoord.y));
				destRow.setInfo(this.shapefilesRowSchema.getDefaultValueId(), new Double(value));

				logger.info("Added dest row:	" + destRow);
			}
		} catch (IteratorException e) {
			Sextante.addErrorToLog(e);
			return;
		} catch (GeoAlgorithmExecutionException e) {
			Sextante.addErrorToLog(e);
			return;
		}

		this.rowsDone();
		this.initialized = true;
	}

	/**
	 * @param copy
	 */
	public ShapefilesQueryRecord(QueryRecord copy) {
		throw new UnsupportedOperationException("Not implemented!");
	}

	/**
	 * 
	 * @return false if there were errors during creating the records from the
	 *         input, true otherwise.
	 */
	public boolean isInitialized() {
		return this.initialized;
	}

}
