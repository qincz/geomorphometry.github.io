/*****************************************************************************
FlowTools flow visualization tools for SEXTANTE algorithm library.
Copyright (C) 2009 Daniel Nüst

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

For more information, contact: daniel.nuest@gmail.com

 *****************************************************************************/
package de.ifgi.sextante.flowTools;

import java.awt.geom.CubicCurve2D;
import java.awt.geom.FlatteningPathIterator;
import java.awt.geom.PathIterator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.log4j.Logger;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.CoordinateSequence;
import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LineString;
import com.vividsolutions.jts.geom.impl.CoordinateArraySequence;

import de.ifgi.sextante.flowTools.flowmap.MyMapProjection;
import de.ifgi.sextante.flowTools.flowmap.ShapefilesQueryRecord;
import de.ifgi.sextante.flowTools.flowmap.ToStringHelper;
import edu.berkeley.guir.prefuse.ItemRegistry;
import edu.stanford.hci.flowmap.cluster.ClusterLayout;
import edu.stanford.hci.flowmap.db.QueryRecord;
import edu.stanford.hci.flowmap.db.QueryRow;
import edu.stanford.hci.flowmap.model.Globals;
import edu.stanford.hci.flowmap.model.UserOptions;
import edu.stanford.hci.flowmap.prefuse.action.ConvertToPrefuse;
import edu.stanford.hci.flowmap.prefuse.action.NodeEdgeRouting;
import edu.stanford.hci.flowmap.prefuse.action.NodeForceScanLayout;
import edu.stanford.hci.flowmap.prefuse.item.FlowDummyNodeItem;
import edu.stanford.hci.flowmap.prefuse.item.FlowEdgeItem;
import edu.stanford.hci.flowmap.prefuse.item.FlowNodeItem;
import edu.stanford.hci.flowmap.prefuse.item.FlowRealNodeItem;
import edu.stanford.hci.flowmap.prefuse.render.SimpleFlowEdgeRenderer;
import edu.stanford.hci.flowmap.prefuse.structure.FlowDummyNode;
import edu.stanford.hci.flowmap.prefuse.structure.FlowEdge;
import edu.stanford.hci.flowmap.prefuse.structure.FlowMapStructure;
import edu.stanford.hci.flowmap.prefuse.structure.FlowNode;
import edu.stanford.hci.flowmap.structure.Graph;
import edu.stanford.hci.flowmap.structure.Node;
import es.unex.sextante.additionalInfo.AdditionalInfoNumericalValue;
import es.unex.sextante.core.Sextante;
import es.unex.sextante.dataObjects.IVectorLayer;
import es.unex.sextante.exceptions.GeoAlgorithmExecutionException;
import es.unex.sextante.exceptions.NullParameterValueException;
import es.unex.sextante.exceptions.OptionalParentParameterException;
import es.unex.sextante.exceptions.RepeatedParameterNameException;
import es.unex.sextante.exceptions.UndefinedParentParameterNameException;
import es.unex.sextante.exceptions.UnsupportedOutputChannelException;
import es.unex.sextante.exceptions.WrongParameterIDException;
import es.unex.sextante.exceptions.WrongParameterTypeException;

/**
 * 
 * @author Daniel Nüst (daniel.nuest@gmail.com)
 * 
 */
public class FlowMapLayoutAlgorithm extends SimpleFlowmapAlgorithm {

	private static final String INPUT_FIELD_USE_CUBIC = "inputBooleanCubic";
	private static final String INPUT_SAMPLING_FLATNESS = "inputFloatSamplingFlattness";
	private static final String INPUT_SAMPLING_POINT_LIMIT = "inputFloatSamplingPointLimit";
	private GeometryFactory m_geomFact;
	private int m_iAddedFeatureCounter = 0;
	private int m_iFailedGeometryCounter = 0;
	private boolean m_bUseCubicLinesInputParam = true;

	private double m_dSamplingFlatness = .1d;
	private int m_iSamplingPointLimit = 2;

	private static Logger logger = Logger
			.getLogger(FlowMapLayoutAlgorithm.class);

	@Override
	public void defineCharacteristics() {
		super.defineCharacteristics();
		this.setName(Sextante.getText("FLOWTOOLS_FML_NAME"));

		try {
			this.m_Parameters.removeParameter(INPUT_FIELD_FLOW);
			this.m_Parameters.addTableField(INPUT_FIELD_FLOW,
					Sextante.getText("FLOWTOOLS_FML_INPUT_FLOW_FIELD"), INPUT_LAYER_DESTINATIONS);
			this.m_Parameters.addBoolean(INPUT_FIELD_USE_CUBIC,
					Sextante.getText("FLOWTOOLS_FML_USE_CUBIC_CURVES"), this.m_bUseCubicLinesInputParam);
			this.m_Parameters.addNumericalValue(INPUT_SAMPLING_FLATNESS,
					Sextante.getText("FLOWTOOLS_FML_MAXIMUM_SAMPLING_FLATNESS"),
					AdditionalInfoNumericalValue.NUMERICAL_VALUE_DOUBLE,
					this.m_dSamplingFlatness, .0d, Double.MAX_VALUE);
			this.m_Parameters.addNumericalValue(INPUT_SAMPLING_POINT_LIMIT,
					Sextante.getText("FLOWTOOLS_FML_SAMPLING_POINT_LIMIT"),
					AdditionalInfoNumericalValue.NUMERICAL_VALUE_INTEGER,
					this.m_iSamplingPointLimit, 0, 20);

		} catch (WrongParameterIDException e) {
			Sextante.addErrorToLog(e);
		} catch (RepeatedParameterNameException e) {
			Sextante.addErrorToLog(e);
		} catch (UndefinedParentParameterNameException e) {
			Sextante.addErrorToLog(e);
		} catch (OptionalParentParameterException e) {
			Sextante.addErrorToLog(e);
		}

		logger.debug("Defined characteristics.");
	}

	@Override
	public boolean processAlgorithm() throws GeoAlgorithmExecutionException {
		logger.info(Sextante.getText("FLOWTOOLS_LOGGER_FML_START"));

		getInputs();

		checkInputs();

		createOutputShapeFile();

		// create lines from source point to all target points with FMT
		try {
			return processFlowMapToolAlgorithm();
		} catch (Exception e) {
			logger.error(e);
			if (e instanceof GeoAlgorithmExecutionException) {
				GeoAlgorithmExecutionException gaee = (GeoAlgorithmExecutionException) e;
				throw gaee;
			}
			if (e instanceof NullPointerException) {
				throw new GeoAlgorithmExecutionException(e.toString());
			}
			throw new GeoAlgorithmExecutionException(e.getMessage() + "\n"
					+ e.getLocalizedMessage() + "\n"
					+ e.getCause().getMessage());
		}
	}

	@Override
	protected void getInputs() throws WrongParameterTypeException,
			WrongParameterIDException, NullParameterValueException {
		super.getInputs();
		this.m_bUseCubicLinesInputParam = this.m_Parameters
				.getParameterValueAsBoolean(INPUT_FIELD_USE_CUBIC);
		this.m_dSamplingFlatness = this.m_Parameters
				.getParameterValueAsDouble(INPUT_SAMPLING_FLATNESS);
		this.m_iSamplingPointLimit = this.m_Parameters
				.getParameterValueAsInt(INPUT_SAMPLING_POINT_LIMIT);
	}

	@Override
	protected void createOutputShapeFile()
			throws UnsupportedOutputChannelException {
		// create empty shape file for output
		String[] sFieldNames;
		this.m_OutputTypes = new Class[3];
		this.m_OutputTypes[0] = String.class;
		this.m_OutputTypes[1] = String.class;
		this.m_OutputTypes[2] = this.m_flowInputParam.getParameterClass();
		sFieldNames = new String[] { "FROM_ID", "TO_ID", "FLOWSIZE" };

		String sDescription = Sextante.getText("FLOWTOOLS_FML_OUTPUT_SHAPE_NAME")
		+ " " + this.m_srcLayer.getName()
		+ " -> " + this.m_destinationLayer.getName();
		
		this.m_Output = getNewVectorLayer(OUTPUT_LAYER, sDescription,
				IVectorLayer.SHAPE_TYPE_LINE, this.m_OutputTypes, sFieldNames);

		logger.debug("Created output file\t"
				+ ToStringHelper.inspect(this.m_Output));
	}

	/**
	 * 
	 * @return
	 * @throws GeoAlgorithmExecutionException
	 */
	private boolean processFlowMapToolAlgorithm()
			throws GeoAlgorithmExecutionException {
		this.m_geomFact = new GeometryFactory();

		// 1. Read data: create records from shape files
		ShapefilesQueryRecord records = new ShapefilesQueryRecord(
				this.m_srcLayer, this.m_idSrcParam, this.m_destinationLayer,
				this.m_idDestParam, this.m_flowInputParam);
		if (!records.isInitialized()) {
			String s = "Error creating query record, not initialized. Check the log for errors.";
			logger.error(s);
			throw new GeoAlgorithmExecutionException(s);
		}

		int i = 0;
		int iCount = records.getRowCount();
		if (this.m_Task.isCanceled()) {
			return false;
		}
		i += iCount / 3;
		setProgress(i, iCount);

		// 2. Set options: create options map and globals
		setGlobals();
		UserOptions options = createUserOptions(records);

		// 3. Create flow map
		FlowNodeItem rootNodeItem = createFlowMap(records, options);

		if (this.m_Task.isCanceled()) {
			return false;
		}
		i += iCount / 3;
		setProgress(i, iCount);

		// 4. Iterate recursively through all edges from the root node on
		String currFlowType = options.getString(UserOptions.CURRENT_FLOW_TYPE);
		iterateGraphAndAddEdges(currFlowType, rootNodeItem);

		if (this.m_Task.isCanceled()) {
			return false;
		}
		i += iCount / 3;
		setProgress(i, iCount);

		// 5. Done
		return !this.m_Task.isCanceled();
	}

	/**
	 * 
	 * @param records
	 * @param options
	 * @return
	 */
	private FlowNodeItem createFlowMap(ShapefilesQueryRecord records,
			UserOptions options) {
		logger
				.info("\n********** CREATING FLOW MAP **********\nuseLayoutAdjustment "
						+ Globals.useLayoutAdjustment
						+ "\t"
						+ "runNodeEdgeRouting " + Globals.runNodeEdgeRouting);

		Graph graph = createGraph(records);

		if (Globals.useLayoutAdjustment) {
			NodeForceScanLayout scanLayout = new NodeForceScanLayout(graph
					.getAllNodes());
			scanLayout.shiftNodes();

			logger.debug("Graph after adjusting node postitions:\n"
					+ ToStringHelper.inspect(graph));
		}

		// first run clustering
		ClusterLayout clusterLayout = new ClusterLayout(graph.getRootNode(),
				graph.getAllNodes());
		Node newRoot = clusterLayout.doLayout();

		if (Globals.runNodeEdgeRouting) {
			NodeEdgeRouting router = new NodeEdgeRouting(newRoot);
			router.routeNodes();

			logger.debug("Graph after edge routing:\n"
					+ ToStringHelper.inspect(graph));
		}

		// then convert to a flow tree
		ConvertToPrefuse converter = new ConvertToPrefuse(createItemRegistry(),
				newRoot);
		FlowNodeItem rootNodeItem = converter.convert();
		logger.debug("Graph after flow tree conversion:\n"
				+ ToStringHelper.inspect(graph));
		logger.debug("Flow tree:\n" + ToStringHelper.inspect(rootNodeItem));

		// create renderer, used because of method "computeEdge" !!!
		SimpleFlowEdgeRenderer renderer = new SimpleFlowEdgeRenderer(options,
				records);
		renderer.setRootNodeItem(rootNodeItem);

		// initialize edges, needs to be done because edges are computed here!
		renderer.initializeRenderTree(rootNodeItem);
		logger.debug("Flow tree after initialization:\n"
				+ ToStringHelper.inspect(rootNodeItem));

		return rootNodeItem;
	}

	/**
	 * 
	 * iterate over all outgoing edges from given node and create the according
	 * shapes, add these to the output file. then iterate recursively through
	 * all outgoing edges.
	 * 
	 * @param currFlowType
	 * @param rootNodeItem
	 * @throws GeoAlgorithmExecutionException
	 */
	private boolean iterateGraphAndAddEdges(String currFlowType,
			FlowNodeItem node) throws GeoAlgorithmExecutionException {
		logger
				.info("********** START going through graph and sampling edges (flatness="
						+ this.m_dSamplingFlatness
						+ ", point limit="
						+ this.m_iSamplingPointLimit
						+ "), iterating edges from node "
						+ node.getName()
						+ " on **********");

		Queue<FlowEdgeItem> edges = new LinkedBlockingQueue<FlowEdgeItem>();
		HashSet<FlowEdgeItem> visitedEdges = new HashSet<FlowEdgeItem>();

		// add outgoing edges to queue
		addAllOutEdges(node, edges, visitedEdges);

		// process queue
		while (!edges.isEmpty()) {
			if (this.m_Task.isCanceled()) {
				return false;
			}

			FlowEdgeItem currentEdge = edges.poll();
			logger.debug("Current edge\t" + currentEdge);

			addEdge(currFlowType, currentEdge);
			visitedEdges.add(currentEdge);

			// add all outgoing edges from second node if they are not visited
			// yet...
			addAllOutEdges((FlowNodeItem) currentEdge.getSecondNode(), edges,
					visitedEdges);
		}

		logger.info("\n********** DONE **********\nAdded "
				+ this.m_iAddedFeatureCounter + "\t Failed "
				+ this.m_iFailedGeometryCounter);

		return true;
	}

	/**
	 * @param node
	 * @param edges
	 * @param visitedEdges
	 */
	private void addAllOutEdges(FlowNodeItem node, Queue<FlowEdgeItem> edges,
			HashSet<FlowEdgeItem> visitedEdges) {
		logger.debug("### Adding " + node.getOutEdges().size()
				+ " more outgoing edges for node " + node + " to queue (size "
				+ edges.size() + ")");
		Iterator<?> edgeIterator = node.getOutEdges().iterator();
		while (edgeIterator.hasNext()) {
			FlowEdgeItem e = (FlowEdgeItem) edgeIterator.next();
			if (!visitedEdges.contains(e))
				edges.add(e);
			else
				logger.debug("### Already visited " + e);
		}
	}

	private void addEdge(String currFlowType, FlowEdgeItem flowEdge)
			throws GeoAlgorithmExecutionException {
		Double edgeWeight = new Double(flowEdge.getWeight(currFlowType));
		FlowNodeItem firstNode = (FlowNodeItem) flowEdge.getFirstNode();
		FlowNodeItem secondNode = (FlowNodeItem) flowEdge.getSecondNode();

		CubicCurve2D curve = flowEdge.getCubicCurve();
		logger.debug("\t\tProcessing curve from " + firstNode.getName()
				+ " to " + secondNode.getName() + " with " + edgeWeight + "\t"
				+ ToStringHelper.inspect(curve));

		// sample bezier curve
		Geometry geom = null;
		if (this.m_bUseCubicLinesInputParam)
			geom = generateSampledCurvyGeometry(curve);
		else
			geom = generateLinearGeometry(curve);

		if (geom != null) {
			// add to output file
			addOutputFeature(geom, firstNode.getName(), secondNode.getName(),
					edgeWeight);
			logger.info("Added output feature\t" + geom + "\t" + edgeWeight);

			this.m_iAddedFeatureCounter++;
		} else {
			logger.error("Could not generate geometry for "
					+ ToStringHelper.inspect(curve));
			this.m_iFailedGeometryCounter++;
		}
	}

	/**
	 * 
	 * @param curve
	 * @param geomFact
	 * @return
	 */
	private Geometry generateLinearGeometry(CubicCurve2D curve) {
		Coordinate[] points = new Coordinate[2];

		double[] p1 = MyMapProjection.inverseMercartorProjection(curve.getY1(),
				curve.getX1());
		double[] p2 = MyMapProjection.inverseMercartorProjection(curve.getY2(),
				curve.getX2());

		points[0] = new Coordinate(p1[0], p1[1]);
		points[1] = new Coordinate(p2[0], p2[1]);

		if (!containsNaNs(points)) {
			logger.debug("\t\tCreating direct LineString from "
					+ Arrays.toString(points));
			CoordinateSequence seq = new CoordinateArraySequence(points);
			LineString line = new LineString(seq, this.m_geomFact);
			return line;
		}
		logger.warn("Found NaN in coordiantes of curve "
				+ ToStringHelper.inspect(curve));
		return null;
	}

	/**
	 * 
	 * @param curve
	 * @return
	 */
	private Geometry generateSampledCurvyGeometry(CubicCurve2D curve) {
		logger.info("***** Sampling curve\t" + ToStringHelper.inspect(curve));

		ArrayList<Coordinate> coords = new ArrayList<Coordinate>();
		PathIterator p = curve.getPathIterator(null);
		FlatteningPathIterator f = new FlatteningPathIterator(p,
				this.m_dSamplingFlatness, this.m_iSamplingPointLimit);

		while (!f.isDone()) {
			double[] pts = new double[6];
			switch (f.currentSegment(pts)) {
			case PathIterator.SEG_MOVETO:
				logger.debug("\tMOVETO, handling as LINETO");
				//$FALL-THROUGH$
			case PathIterator.SEG_LINETO: {
				// g2.fill(new Ellipse2D.Float(pts[0], pts[1],3,3));
				double[] p1 = MyMapProjection.inverseMercartorProjection(
						pts[1], pts[0]);

				Coordinate c = new Coordinate(p1[0], p1[1]);
				coords.add(c);
				logger.debug("\tAdded Coordinate " + c + "\tin LINETO from "
						+ Arrays.toString(pts));
				break;
			}
			case PathIterator.SEG_CLOSE:
				logger.debug("\tCLOSE" + Arrays.toString(pts));
				break;
			case PathIterator.SEG_CUBICTO:
				logger.debug("\tCUBICTO" + Arrays.toString(pts));
				break;
			case PathIterator.SEG_QUADTO:
				logger.debug("\tQUADTO" + Arrays.toString(pts));
				break;
			default:
				break;
			}
			f.next();
		}

		Coordinate[] points = new Coordinate[coords.size()];
		int i = 0;
		for (Coordinate coordinate : coords) {
			points[i] = coordinate;
			i++;
		}
		logger.info("***** Sampled curve has " + points.length + " points");

		if (!containsNaNs(points)) {
			logger.debug("Creating LineString from " + Arrays.toString(points));
			CoordinateSequence seq = new CoordinateArraySequence(points);
			LineString line = new LineString(seq, this.m_geomFact);
			return line;
		}
		logger.warn("Found NaN in coordiantes of curve "
				+ ToStringHelper.inspect(curve));
		return null;
	}

	/**
	 * 
	 * @param points
	 * @return
	 */
	private boolean containsNaNs(Coordinate[] points) {
		for (Coordinate coordinate : points) {
			if (Double.isNaN(coordinate.x) || Double.isNaN(coordinate.y))
				return true;
		}
		return false;
	}

	/**
	 * 
	 */
	private void setGlobals() {
		Globals.useLayoutAdjustment = false;
		Globals.runNodeEdgeRouting = true;
	}

	/**
	 * @param records
	 * @return
	 */
	private UserOptions createUserOptions(ShapefilesQueryRecord records) {
		UserOptions options = new UserOptions();
		// needed to access the weight in flow tree
		options.putString(UserOptions.CURRENT_FLOW_TYPE, records.getSourceRow()
				.getRowSchema().getDefaultValueId());
		// display options do not matter but are required by following
		// calculations
		options.putBoolean(UserOptions.LINEAR_SCALE, true);
		options.putDouble(UserOptions.MIN_DISPLAY_WIDTH, 1.0d);
		options.putDouble(UserOptions.MAX_DISPLAY_WIDTH, 1.0d);
		return options;
	}

	/**
	 * @return
	 */
	private ItemRegistry createItemRegistry() {
		ItemRegistry registry = new ItemRegistry(new FlowMapStructure());
		registry.addItemClass(FlowNode.class.getName(), FlowRealNodeItem.class);
		registry.addItemClass(FlowDummyNode.class.getName(),
				FlowDummyNodeItem.class);
		registry.addItemClass(FlowEdge.class.getName(), FlowEdgeItem.class);
		return registry;
	}

	/**
	 * 
	 * @param flowRecord
	 * @return
	 */
	private Graph createGraph(QueryRecord flowRecord) {
		Graph graph = new Graph();

		assert (flowRecord.getSourceRow() != null);
		Node rootNode = new Node(flowRecord.getSourceRow());
		rootNode.setRootNode(true);

		graph.addNode(rootNode);
		graph.setRootNode(rootNode);

		QueryRow row;
		Node dest;
		Iterator<?> i = flowRecord.getRowsIterator();

		while (i.hasNext()) {
			row = (QueryRow) i.next();

			// if the root node is a destination, just ignore it
			if (row.getName().equals(rootNode.getName())) {
				continue;
			}

			dest = new Node(row);
			graph.addNode(dest);
		}

		logger
				.info("**** GRAPH CREATED ****\n"
						+ ToStringHelper.inspect(graph));

		return graph;
	}
}