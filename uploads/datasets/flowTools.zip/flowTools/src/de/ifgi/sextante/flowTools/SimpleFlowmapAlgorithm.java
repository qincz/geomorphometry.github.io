/*****************************************************************************
FlowTools flow visualization tools for SEXTANTE algorithm library.
Copyright (C) 2009 Daniel Nüst

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

For more information, contact: daniel.nuest@gmail.com

 *****************************************************************************/
package de.ifgi.sextante.flowTools;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.geom.GeometryFactory;
import com.vividsolutions.jts.geom.LineString;

import de.ifgi.sextante.flowTools.flowmap.ToStringHelper;
import es.unex.sextante.core.GeoAlgorithm;
import es.unex.sextante.core.Sextante;
import es.unex.sextante.dataObjects.IFeature;
import es.unex.sextante.dataObjects.IFeatureIterator;
import es.unex.sextante.dataObjects.IVectorLayer;
import es.unex.sextante.exceptions.GeoAlgorithmExecutionException;
import es.unex.sextante.exceptions.NullParameterValueException;
import es.unex.sextante.exceptions.OptionalParentParameterException;
import es.unex.sextante.exceptions.RepeatedParameterNameException;
import es.unex.sextante.exceptions.UndefinedParentParameterNameException;
import es.unex.sextante.exceptions.UnsupportedOutputChannelException;
import es.unex.sextante.exceptions.WrongParameterIDException;
import es.unex.sextante.exceptions.WrongParameterTypeException;
import es.unex.sextante.parameters.Parameter;

/**
 * Simple flow map visualizer. Inputs are a shape file with the
 * source/destination point and a shape file with the destinations points/source
 * points. The latter also contains an attribute for the flow's strength/size.
 * 
 * Straight lines are created from the source to the destinations which have the
 * unchanged flow value as an attribute.
 * 
 * @author Daniel Nüst (daniel.nuest@gmail.com)
 * 
 */
public class SimpleFlowmapAlgorithm extends GeoAlgorithm {

	public static final String ALGORITHM_GROUP = "Flow Maps";

	protected static final String INPUT_LAYER_SOURCE = "inputLayerSource";
	protected static final String INPUT_LAYER_DESTINATIONS = "inputLayerDestinations";
	protected static final String OUTPUT_LAYER = "outputLayer";
	protected static final String INPUT_FIELD_FLOW = "inputFieldFlow";
	protected static final String INPUT_FIELD_ID_DEST = "inputFieldIdDest";
	protected static final String INPUT_FIELD_ID_SRC = "inputFieldIdSrc";
	protected IVectorLayer m_Output;
	protected IVectorLayer m_srcLayer;
	protected IVectorLayer m_destinationLayer;
	protected Parameter m_idSrcParam;
	protected Parameter m_idDestParam;
	protected Parameter m_flowInputParam;
	protected Class<?>[] m_OutputTypes;

	private static Logger logger = Logger
			.getLogger(SimpleFlowmapAlgorithm.class);

	/**
	 * 
	 */
	@Override
	public void defineCharacteristics() {
		this.setName(Sextante.getText("FLOWTOOLS_SIMPLE_NAME"));
		this.setGroup(ALGORITHM_GROUP);
		this.m_bGeneratesRasterOutput = false;

		defineInputs();
	}

	/**
	 * 
	 */
	@Override
	public boolean processAlgorithm() throws GeoAlgorithmExecutionException {
		logger.info(Sextante.getText("FLOWTOOLS_LOGGER_SIMPLE_START"));

		getInputs();

		checkInputs();

		createOutputShapeFile();

		// get coordinates and id of the source point
		IFeature srcFeature = this.m_srcLayer.iterator().next();
		Coordinate srcCoord = srcFeature.getGeometry().getCoordinate();
		Object srcID = srcFeature.getRecord().getValue(
				this.m_idSrcParam.getParameterValueAsInt());

		// create straight lines from source point to all target points
		GeometryFactory geomFact = new GeometryFactory();
		IFeatureIterator iter = this.m_destinationLayer.iterator();
		int i = 0;
		int iCount = this.m_destinationLayer.getShapesCount();
		while (iter.hasNext() && setProgress(i, iCount)) {
			IFeature feature = iter.next();
			Coordinate destCoord = feature.getGeometry().getCoordinate();
			LineString straightLine = geomFact
					.createLineString(new Coordinate[] { srcCoord, destCoord });

			Object destID = feature.getRecord().getValue(
					this.m_idDestParam.getParameterValueAsInt());
			Object flowSize = feature.getRecord().getValue(
					this.m_flowInputParam.getParameterValueAsInt());

			addOutputFeature(straightLine, srcID, destID, flowSize);

			logger.debug("Added " + straightLine + "\t\tfrom " + srcID + " to "
					+ destID + "\tflow = " + flowSize);
			i++;

			if (this.m_Task.isCanceled()) {
				return false;
			}
		}

		return !this.m_Task.isCanceled();
	}

	/**
	 * 
	 */
	protected void defineInputs() {
		try {
			this.m_Parameters.addInputVectorLayer(INPUT_LAYER_SOURCE, Sextante
					.getText("FLOWTOOLS_SIMPLE_INPUT_POINT_SHAPE_SRC"),
					IVectorLayer.SHAPE_TYPE_POINT, true);
			this.m_Parameters
					.addInputVectorLayer(
							INPUT_LAYER_DESTINATIONS,
							Sextante
									.getText("FLOWTOOLS_SIMPLE_INPUT_POINT_SHAPE_DEST"),
							IVectorLayer.SHAPE_TYPE_POINT, true);

			this.m_Parameters.addTableField(INPUT_FIELD_ID_SRC, Sextante
					.getText("FLOWTOOLS_SIMPLE_INPUT_ID_FIELD"),
					INPUT_LAYER_SOURCE);
			this.m_Parameters.addTableField(INPUT_FIELD_ID_DEST, Sextante
					.getText("FLOWTOOLS_SIMPLE_INPUT_ID_FIELD"),
					INPUT_LAYER_DESTINATIONS);
			this.m_Parameters.addTableField(INPUT_FIELD_FLOW, Sextante
					.getText("FLOWTOOLS_SIMPLE_INPUT_FLOW_FIELD"),
					INPUT_LAYER_DESTINATIONS);

			addOutputVectorLayer(OUTPUT_LAYER, Sextante
					.getText("FLOWTOOLS_SIMPLE_OUTPUT_SHAPE_DESCRIPTION") + " ",
					IVectorLayer.SHAPE_TYPE_LINE);

		} catch (RepeatedParameterNameException e0) {
			Sextante.addErrorToLog(e0);
		} catch (OptionalParentParameterException e1) {
			Sextante.addErrorToLog(e1);
		} catch (UndefinedParentParameterNameException e2) {
			Sextante.addErrorToLog(e2);
		}
	}

	/**
	 * 
	 * @throws WrongParameterTypeException
	 * @throws WrongParameterIDException
	 * @throws NullParameterValueException
	 */
	protected void getInputs() throws WrongParameterTypeException,
			WrongParameterIDException, NullParameterValueException {
		// get the inputs
		this.m_srcLayer = this.m_Parameters
				.getParameterValueAsVectorLayer(INPUT_LAYER_SOURCE);
		this.m_destinationLayer = this.m_Parameters
				.getParameterValueAsVectorLayer(INPUT_LAYER_DESTINATIONS);

		this.m_idSrcParam = this.m_Parameters.getParameter(INPUT_FIELD_ID_SRC);
		this.m_idDestParam = this.m_Parameters
				.getParameter(INPUT_FIELD_ID_DEST);
		this.m_flowInputParam = this.m_Parameters
				.getParameter(INPUT_FIELD_FLOW);
	}

	/**
	 * 
	 * @return
	 * @throws GeoAlgorithmExecutionException
	 */
	protected void checkInputs() throws GeoAlgorithmExecutionException {
		// check the inputs
		if (this.m_srcLayer.getShapesCount() != 1) {
			String s = Sextante.getText("FLOWTOOLS_ERROR_INPUT_1");
			Sextante.addErrorToLog(s);
			throw new GeoAlgorithmExecutionException(s);
		}

		// check for same reference system done in GeoAlgorithm...

		// check that flow value is numeric
		List<Class<?>> allowed = new ArrayList<Class<?>>();
		allowed.add(Float.class);
		allowed.add(Double.class);
		allowed.add(Integer.class);
		allowed.add(Long.class);

		if (!allowed.contains(this.m_flowInputParam.getParameterClass())) {
			String s = Sextante.getText("FLOWTOOLS_ERROR_INPUT_NUMERIC_1")
					+ " ("
					+ this.m_flowInputParam.getParameterClass().getName() + ")"
					+ ". "
					+ Sextante.getText("FLOWTOOLS_ERROR_INPUT_NUMERIC_2");
			logger.error(s);
			throw new GeoAlgorithmExecutionException(s);
		}
	}

	/**
	 * 
	 * @throws UnsupportedOutputChannelException
	 */
	protected void createOutputShapeFile()
			throws UnsupportedOutputChannelException {
		// create empty shape file for output
		String[] sFieldNames;
		this.m_OutputTypes = new Class[3];
		this.m_OutputTypes[0] = this.m_idSrcParam.getParameterClass();
		this.m_OutputTypes[1] = this.m_idDestParam.getParameterClass();
		this.m_OutputTypes[2] = this.m_flowInputParam.getParameterClass();
		sFieldNames = new String[] { "FROM_ID", "TO_ID", "FLOWSIZE" };

		String sDescription = Sextante
				.getText("FLOWTOOLS_SIMPLE_OUTPUT_SHAPE_NAME")
				+ " "
				+ this.m_srcLayer.getName()
				+ " -> "
				+ this.m_destinationLayer.getName();
		this.m_Output = getNewVectorLayer(OUTPUT_LAYER, sDescription,
				IVectorLayer.SHAPE_TYPE_LINE, this.m_OutputTypes, sFieldNames);

		logger.info("Created output file\t"
				+ ToStringHelper.inspect(this.m_Output));
	}

	/**
	 * 
	 * @param geom
	 * @param from
	 * @param to
	 * @param flow
	 * @throws GeoAlgorithmExecutionException
	 */
	protected void addOutputFeature(Geometry geom, Object from, Object to,
			Object flow) throws GeoAlgorithmExecutionException {
		Object[] values = new Object[3];

		values[0] = castOrParseNumber(from, this.m_OutputTypes[0]);
		values[1] = castOrParseNumber(to, this.m_OutputTypes[1]);
		values[2] = castOrParseNumber(flow, this.m_OutputTypes[2]);

		this.m_Output.addFeature(geom, values);
	}

	/**
	 * 
	 * @param theObject
	 * @param theType
	 * @return
	 * @throws GeoAlgorithmExecutionException
	 */
	private Object castOrParseNumber(Object theObject, Class<?> theType)
			throws GeoAlgorithmExecutionException {
		// convert to correct runtime classes
		if (theObject.getClass() != theType) {
			try {
				return theType.cast(theObject);
			} catch (ClassCastException e) {
				return parseNumberClass(theObject.toString(), theType);
			}
		}
		return theObject;
	}

	/**
	 * @param theNumber
	 * @param theType
	 * @throws GeoAlgorithmExecutionException
	 */
	private Object parseNumberClass(Object theNumber, Class<?> theType)
			throws GeoAlgorithmExecutionException {
		if (theNumber instanceof String) {
			String s = (String) theNumber;
			if (theType.equals(Double.class)) {
				return new Double(s);
			} else if (theType.equals(Integer.class)) {
				if (s.contains(".") || s.contains(","))
					return Integer.valueOf(Long.valueOf(
							Math.round(Double.parseDouble(s))).intValue());
				return new Integer(s);
			} else if (theType.equals(Long.class)) {
				if (s.contains(".") || s.contains(","))
					return new Integer(Long.valueOf(
							Math.round(Double.parseDouble(s))).intValue());
				return new Long(s);
			} else if (theType.equals(Float.class)) {
				return new Float(s);
			}

			return theNumber;
		}
		throw new GeoAlgorithmExecutionException(Sextante
				.getText("FLOWTOOLS_ERROR_PARSE_1")
				+ " " + theType + ": " + theNumber);
	}
}