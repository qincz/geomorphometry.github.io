/*****************************************************************************
FlowTools flow visualization tools for SEXTANTE algorithm library.
Copyright (C) 2009 Daniel Nüst

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

For more information, contact: daniel.nuest@gmail.com

 *****************************************************************************/
package de.ifgi.sextante.flowTools.flowmap;

import java.awt.Shape;
import java.awt.geom.CubicCurve2D;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;

import edu.stanford.hci.flowmap.prefuse.item.FlowEdgeItem;
import edu.stanford.hci.flowmap.prefuse.item.FlowNodeItem;
import edu.stanford.hci.flowmap.structure.Edge;
import edu.stanford.hci.flowmap.structure.Graph;
import edu.stanford.hci.flowmap.structure.Node;
import es.unex.sextante.dataObjects.IVectorLayer;

/**
 * 
 * Helper class that provides static methods to inspect objects in the command
 * line which do not have a sufficient toString() method.
 * 
 * @author Daniel Nüst (daniel.nuest@gmail.com)
 * 
 */
public class ToStringHelper {

	/**
	 * Returns a string representation of the given object.
	 * 
	 * @param o
	 * @return A string describing the given object using methods given in this
	 *         class, or the standart toString as a fall back mechanism.
	 */
	public static String inspect(Object o) {
		return o.toString();
	}

	/**
	 * Returns a string representation of the given object.
	 * 
	 * @param myCurve
	 * @return
	 */
	public static String inspect(CubicCurve2D myCurve) {
		if (myCurve == null)
			return "is NULL";

		StringBuilder sb = new StringBuilder();
		sb.append(" P1=");
		sb.append(myCurve.getP1());
		sb.append(" P2=");
		sb.append(myCurve.getP2());
		sb.append("[ CtrlP1=");
		sb.append(myCurve.getCtrlP1());
		sb.append(" CtrlP2=");
		sb.append(myCurve.getCtrlP2());
		sb.append(" flatness=");
		sb.append(myCurve.getFlatness());
		sb.append(" ]");
		return sb.toString();
	}

	/**
	 * Returns a string representation of the given object.
	 * 
	 * @param shape
	 * @return
	 */
	public static String inspect(Shape shape) {
		if (shape instanceof CubicCurve2D) {
			CubicCurve2D curve = (CubicCurve2D) shape;
			return inspect(curve);
		}
		return shape.toString();
	}

	/**
	 * Returns a string representation of the given object.
	 * 
	 * @param graph
	 * @return
	 */
	public static String inspect(Graph graph) {
		StringBuilder sb = new StringBuilder();
		sb.append("[ GRAPH root node ");
		sb.append(inspect(graph.getRootNode()));
		sb.append("\n\t[ OUT EDGES ");
		for (Edge e : graph.getRootNode().getOutEdges()) {
			sb.append("\n\t\t");
			sb.append(inspect(e));
		}
		sb.append(" ] ]");
		return sb.toString();
	}

	/**
	 * Returns a string representation of the given object.
	 * 
	 * @param e
	 * @return
	 */
	public static String inspect(Edge e) {
		StringBuilder sb = new StringBuilder();
		sb.append("[ EDGE weight=");
		sb.append(e.getWeight());
		sb.append(", 1st node ");
		sb.append(inspect(e.getFirstNode()));
		sb.append(", 2nd node ");
		sb.append(inspect(e.getSecondNode()));
		sb.append(" ]");
		return sb.toString();
	}

	/**
	 * Returns a string representation of the given object.
	 * 
	 * @param n
	 * @return
	 */
	public static String inspect(Node n) {
		StringBuilder sb = new StringBuilder();
		sb.append("[ NODE id=");
		sb.append(n.getID());
		sb.append(", name=");
		sb.append(n.getName());
		sb.append(", location=");
		sb.append(n.getLocation());
		sb.append(", query row=");
		sb.append(n.getQueryRow());
		sb.append(" ]");
		return sb.toString();
	}

	/**
	 * Returns a string representation of the given object.
	 * 
	 * @param nodes
	 * @return
	 */
	public static String inspect(Collection<Node> nodes) {
		StringBuilder sb = new StringBuilder();
		sb.append("[ NODE COLLECTION");
		for (Node n : nodes) {
			sb.append("\n\t");
			sb.append(inspect(n));
		}
		sb.append(" ]");
		return sb.toString();
	}

	/**
	 * Returns a string representation of the given object.
	 * 
	 * @param rootNodeItem
	 * @return
	 */
	public static String inspect(FlowNodeItem rootNodeItem) {
		StringBuilder sb = new StringBuilder();
		sb.append("[ FLOW NODE ITEM id=");
		sb.append(rootNodeItem.getID());
		sb.append(", name=");
		sb.append(rootNodeItem.getName());
		sb.append(", location=");
		sb.append(rootNodeItem.getLocation());
		sb.append(", weight=");
		sb.append(rootNodeItem.getWeight());
		sb.append(", edge count=");
		sb.append(rootNodeItem.getEdgeCount());
		sb.append(", attribute=");
		sb.append(inspect(rootNodeItem.getAttributes()));
		sb.append("\t[ OUT EDGES ");
		for (Object item : rootNodeItem.getOutEdges()) {
			FlowEdgeItem e = (FlowEdgeItem) item;
			sb.append("\n\t");
			sb.append(inspect(e));
		}
		sb.append(" ]");
		sb.append("\n\t[ TREE ");
		sb.append(printTree(rootNodeItem));
		sb.append(" ]");
		sb.append(" ]");
		return sb.toString();
	}

	/**
	 * Returns a string representation of the given object.
	 * 
	 * @param attributes
	 * @return
	 */
	private static String inspect(Map<?, ?> attributes) {
		StringBuilder sb = new StringBuilder();
		sb.append("[ MAP ");
		Iterator<?> iter = attributes.entrySet().iterator();
		while (iter.hasNext()) {
			Entry<?, ?> entry = (Entry<?, ?>) iter.next();
			sb.append(entry.getKey().toString());
			sb.append("=");
			sb.append(entry.getValue().toString());
		}
		sb.append(" ]");
		return sb.toString();
	}

	/**
	 * Returns a string representation of the given object.
	 * 
	 * @param e
	 * @return
	 */
	public static String inspect(FlowEdgeItem e) {
		if (e == null)
			return "is NULL";

		StringBuilder sb = new StringBuilder();
		sb.append("[ FLOWEDGEITEM size ");
		sb.append(e.getSize());
		sb.append(", curve ");
		try {
			sb.append(inspect(e.getCubicCurve()));
		} catch (RuntimeException re) {
			if (re.getMessage().contains(
					"Asked for a cubic curve when we really have a null")) {
				sb.append(" IS NULL");
			} else
				sb.append(re.getMessage());
		}
		sb.append(", attributes ");
		sb.append(inspect(e.getAttributes()));
		sb.append(" ]");
		return sb.toString();
	}

	/**
	 * Returns a string representation of the given object.
	 * 
	 * @param rootItem
	 * @return
	 */
	private static String printTree(FlowNodeItem rootItem) {
		StringBuffer sb = new StringBuffer();
		sb.append("[ ConvertToPrefuse.PrintingTree");
		LinkedList<FlowNodeItem> queue = new LinkedList<FlowNodeItem>();
		queue.add(rootItem);
		while (queue.size() > 0) {
			FlowNodeItem n = queue.removeFirst();
			sb.append("\n\t");
			sb.append(n);
			sb.append("\n\t\tOutgoing Edges");
			Iterator<?> i = n.getOutEdges().iterator();
			while (i.hasNext()) {
				Object o = i.next();
				FlowEdgeItem edge = (FlowEdgeItem) o;
				sb.append("\n\t\t\t" + edge);
				queue.add((FlowNodeItem) edge.getSecondNode());
			}
			sb.append("\n\t\tIncoming Edges");
			i = n.getInEdges().iterator();
			while (i.hasNext()) {
				Object o = i.next();
				FlowEdgeItem edge = (FlowEdgeItem) o;
				sb.append("\n\t\t\t" + edge);
				// queue.add((FlowNodeItem) edge.getSecondNode());
			}
		}
		sb.append(" ]\nDonePrintingTree ]");
		return sb.toString();
	}

	/**
	 * Returns a string representation of the given object.
	 * 
	 * @param layer
	 * @return
	 */
	public static String inspect(IVectorLayer layer) {
		StringBuilder sb = new StringBuilder();
		sb.append("[ IVECTORLAYER ");
		sb.append(layer.getName());
		sb.append(", file=");
		sb.append(layer.getFilename());
		sb.append(", field names=");
		sb.append(Arrays.toString(layer.getFieldNames()));
		sb.append(", #shapes=");
		sb.append(layer.getShapesCount());
		sb.append(", extent=");
		sb.append(layer.getFullExtent());
		sb.append(", crs=");
		sb.append(layer.getCRS());
		sb.append(" ]");
		return sb.toString();
	}
}
