/*****************************************************************************
FlowTools flow visualization tools for SEXTANTE algorithm library.
Copyright (C) 2009 Daniel Nüst

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

For more information, contact: daniel.nuest@gmail.com

 *****************************************************************************/
package de.ifgi.sextante.flowTools.flowmap;

import java.awt.geom.Point2D;

import org.apache.log4j.Logger;

import edu.stanford.hci.flowmap.db.QueryRow;
import edu.stanford.hci.flowmap.db.RowSchema;
import edu.stanford.hci.flowmap.layout.GeographicPositionLayout;

/**
 * 
 * Changes to {@link GeographicPositionLayout}: Does not use any screen
 * projection when computing the positions as that is done by the client using
 * this algorithm. The constructor does also not take any screem dimensions, as
 * they are not needed.
 * 
 * @author Daniel Nüst (daniel.nuest@gmail.com)
 * 
 */
public class MyGeographicPositionLayout extends GeographicPositionLayout {

	private String latitude, longitude;
	private static final int NAME_COLUMN = 1;
	private static final int X_COLUMN = 2;
	private static final int Y_COLUMN = 3;
	private static final int VALUE_COLUMN = 4;

	private static Logger logger = Logger
			.getLogger(MyGeographicPositionLayout.class);

	/**
	 * 
	 * @param d
	 */
	public MyGeographicPositionLayout() {
		// super(new Dimension(1000, 1000));
		super(null);
		this.latitude = this.longitude = null;
	}

	/**
	 * changes: - using {@link MyMapProjection} - using no screen projection at
	 * all
	 */
	@Override
	public Point2D computePostion(QueryRow row) {
		double lat = row.getValue(this.latitude);
		double lon = row.getValue(this.longitude);

		Point2D pt = getPoint(lon, lat);

		pt = MyMapProjection.mercatorProjection(pt.getY(), pt.getX());

		logger
				.debug("Projected point from\t" + lat + "," + lon + "\tto\t"
						+ pt);
		return pt;
	}

	/**
	 * Sets the column mapping
	 * 
	 * @param index
	 *            the index of the data
	 * @param name
	 *            the name of the type
	 * @param rowSchema
	 *            the row schema to use
	 */
	@Override
	public void setColumnMapping(int index, String name, RowSchema rowSchema) {
		switch (index) {
		case NAME_COLUMN:
			rowSchema.setNameId(name);
			break;
		case X_COLUMN:
			rowSchema.setXId(name);
			this.longitude = name;
			break;
		case Y_COLUMN:
			rowSchema.setYId(name);
			this.latitude = name;
			break;
		case VALUE_COLUMN:
			rowSchema.setValueId(name);
			break;
		}
	}
}