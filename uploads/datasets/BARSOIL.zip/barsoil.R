# Script to interpolate soil thickness and occurrence of gley horizon using land-surface parameters and mapping units
# prepared for the needs of book "Geomorphometry: concepts, software, applications"
# Developed by T. Hengl (spatial-analyst.net)
# In Amsterdam, Netherlands, May 2009.
# Inputs: baranja.txt - 59 field profile observations; SLOPE.asc, PROFC.asc, PLANC.asc, TWI.asc, SINS.asc, SMU1.asc, SMU2.asc, SMU3.asc, SMU4.asc, SMU5.asc, SMU6.asc, SMU7.asc, SMU8.asc, SMU9.asc,
# Coordinate system Gauss Kruger zone 6 (gk_6);

# Import the profile data to R:

objects()
baranja <- read.delim("baranja.txt")

# Look at the histograms:

hist(baranja$SOLUM, col="grey")
hist(baranja$GLEY_P, col="grey")

# Convert the table to a point map:

library(maptools)
coordinates(baranja)=~X+Y
summary(baranja)

# Visualize the maps:

bubble(baranja, "SOLUM", scales=list(draw=TRUE, cex=0.8))
bubble(baranja, "GLEY_P", scales=list(draw=TRUE, cex=0.8))

# Import all raster maps:

library(rgdal)
# get a list of all maps:
asc.list <- list.files(getwd(), pattern="\\.asc$", full=F)
asc.list
grids <- readGDAL(asc.list[[1]])
for(i in 1:(length(asc.list)-1)){
   grids@data[[i+1]] <- readGDAL(asc.list[[i+1]])$band1 
}
names(grids) <- sub(".asc", "", asc.list)
summary(grids)

spplot(grids["TWI"], col.regions=bpy.colors())

# Overlay points over SPCs

baranja.ov <- overlay(grids, baranja)
baranja.ov@data <- cbind(baranja.ov@data, baranja@data)
str(baranja.ov@data)

# Run multiple linear regression and then step-wise regression
# First only land-surface parameters:

summary(test1.fit <- lm(SOLUM~DEM+SLOPE+PLANC+PROFC+TWI+SINS, data=baranja.ov))
# test1.step <- step(test1.fit)
# summary(test1.step)

summary(test2.fit <- lm(GLEY_P~DEM+SLOPE+PLANC+PROFC+TWI+SINS, data=baranja.ov))
# test2.step <- step(test2.fit)
# summary(test2.step)

# Now also include soil mapping units:

summary(solum.fit <- lm(SOLUM~DEM+SLOPE+PLANC+PROFC+TWI+SINS+SMU1+SMU2+SMU3+SMU4+SMU5+SMU7+SMU8+SMU9, data=baranja.ov))
solum.step <- step(solum.fit)
summary(solum.step)

summary(gleyp.fit <- lm(GLEY_P~DEM+SLOPE+PLANC+PROFC+TWI+SINS+SMU1+SMU2+SMU3+SMU4+SMU5+SMU7+SMU8+SMU9, data=baranja.ov))
gleyp.step <- step(gleyp.fit)
summary(gleyp.step)

# The occurrence of a horizon is in fact a binomial variable, hence we need to use:
gleyp.glm <- glm(gleyp.step$call$formula, binomial(link=logit), data=baranja.ov) 
summary(gleyp.glm)
gleyp.glm$tresiduals <- gleyp.glm$fitted.values - gleyp.glm$model$GLEY_P

# Fit variograms
# First fit variograms for the original target variables:

library(gstat)
plot(variogram(SOLUM~1, baranja))
SOLUM.v <- variogram(SOLUM~1, baranja)
SOLUM.ovgm <- fit.variogram(SOLUM.v, vgm(nugget=0, "Exp", range=sqrt(diff(baranja@bbox[1,])^2 + diff(baranja@bbox[2,])^2)/4, psill=var(baranja$SOLUM)))
plot(SOLUM.v, SOLUM.ovgm, plot.nu=T)
# Warning: singular model in variogram fit

plot(variogram(GLEY_P~1, baranja))
GLEYP.v <- variogram(GLEY_P~1, baranja)
GLEYP.ovgm <- fit.variogram(GLEYP.v, vgm(nugget=0.01, model="Exp", range=sqrt(diff(baranja@bbox[1,])^2 + diff(baranja@bbox[2,])^2)/4, psill=var(baranja$GLEY_P)))
plot(GLEYP.v, GLEYP.ovgm, plot.nu=T)
# Note: GLEY_P shows no spatial auto-correlation
# Estimate the variogram parameters manually

# Then for residuals:

plot(variogram(solum.step$call$formula, baranja))
SOLUM.rv <- variogram(solum.step$call$formula, baranja.ov)
SOLUM.rvgm <- fit.variogram(SOLUM.rv, vgm(0, model="Exp", range=sqrt(diff(baranja@bbox[1,])^2 + diff(baranja@bbox[2,])^2)/4, psill=var(solum.step$residuals)))
plot(SOLUM.rv, SOLUM.rvgm, plot.nu=T)

plot(variogram(gleyp.glm$tresiduals~1, data=gleyp.glm$data))
GLEYP.rebin <- variogram(gleyp.glm$tresiduals~1, data=gleyp.glm$data)
GLEYP.rbvgm <- fit.variogram(GLEYP.rebin, vgm(nugget=0.01, model="Exp", range=400, psill=0.03))
plot(GLEYP.rebin, GLEYP.rbvgm, plot.nu=T)
# Note: Also the residuals of GLEY_P show no spatial auto-correlation (pure nugget effect)


# Interpolate the target variables by ordinary kriging:

SOLUM.ok <- krige(SOLUM~1, baranja, grids, SOLUM.ovgm)
GLEY_P.ok <- krige(GLEY_P~1, baranja, grids, GLEYP.ovgm)

# Visualize the results:

spplot(SOLUM.ok[1], col.regions=bpy.colors(), at = seq(25,100,2), sp.layout = list("sp.points", pch="+", col="cyan", baranja))
spplot(GLEY_P.ok[1], col.regions=bpy.colors(), at = seq(0,1,0.05), sp.layout = list("sp.points", pch="+", col="cyan", baranja))
# Note: because of the pure nugget effect, there is not much sense of mapping GLEY_P using OK;

# Then by regression-kriging:

SOLUM.rk <- krige(solum.step$call$formula, baranja.ov, grids, SOLUM.rvgm)
spplot(SOLUM.rk[1], col.regions=bpy.colors(), at = seq(0,120,2), sp.layout = list("sp.points", pch="+", col="cyan", baranja))

GLEY_P.rk <- krige(gleyp.step$call$formula, baranja.ov, grids, vgm(0.03, "Nug", 0))
spplot(GLEY_P.rk[1], col.regions=bpy.colors(), at=seq(0,1,0.01), sp.layout = list("sp.points", pch="+", col="cyan", baranja))
# this will produce values outside the 0-1 range;

# Instead, we run predictions by regression first, then kriging of residuals:
GLEY_P.trend <- predict(gleyp.glm, newdata=grids, type="response")
GLEY_P.gres <- gstat(id=c("GLEY_P"), formula=gleyp.glm$tresiduals~1, data=baranja, model=GLEYP.rbvgm)
GLEY_P.rkbin <- predict.gstat(GLEY_P.gres, grids, beta=1, BLUE=FALSE)
GLEY_P.rkbin$pred.bin <- GLEY_P.trend + GLEY_P.rkbin$GLEY_P.pred
GLEY_P.rkbin$bin <- ifelse(GLEY_P.rkbin$pred.bin<0, 0, ifelse(GLEY_P.rkbin$pred.bin>1, 1, GLEY_P.rkbin$pred.bin))
spplot(GLEY_P.rkbin["bin"], col.regions=bpy.colors(), at=seq(0,1,0.01), sp.layout=list("sp.points", pch="+", col="cyan", baranja))
# now all the values are forced between the 0-1 range!

# You can also produce simulations using the same model:

SOLUM.rksim <- krige(solum.step$call$formula, baranja.ov, grids, SOLUM.rvgm, nmax=40, nsim=2)
GLEY_P.rksim <- krige(gleyp.step$call$formula, baranja.ov, grids, vgm(0.03, "Nug", 0), nmax=40, nsim=2)

spplot(SOLUM.rksim[1], col.regions=bpy.colors(), at = seq(0,120,2), sp.layout = list("sp.points", pch="+", col="cyan", baranja))
spplot(GLEY_P.rksim[1], col.regions=bpy.colors(), at = seq(0,1,0.05), sp.layout = list("sp.points", pch="+", col="cyan", baranja))

# Notes: due to a low number of profile observations, it is not easy to get a reliable estimate of the variogram model;
# For more details see: Dobos, E., Hengl T. 2008. Soil Mapping Applications. In: Hengl, T. and Reuter, H.I. (Eds),  Geomorphometry: Geomorphometry: Concepts, Software, Applications. Developments in Soil Science, vol. 33, Elsevier.

# Export the results to a GIS format:

write.asciigrid(SOLUM.ok[1], "SOLUM_ok.asc")
write.asciigrid(SOLUM.rk[1], "SOLUM_rk.asc")
write.asciigrid(SOLUM.rksim[1], "SOLUM_rksim01.asc")
write.asciigrid(GLEY_P.ok[1], "GLEYP_ok.asc")
write.asciigrid(GLEY_P.rkbin["bin"], "GLEYP_rk.asc")
write.asciigrid(GLEY_P.rksim[1], "GLEYP_rksim01.asc")