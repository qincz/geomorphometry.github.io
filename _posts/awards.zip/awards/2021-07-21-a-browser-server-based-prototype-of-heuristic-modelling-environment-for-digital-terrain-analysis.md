---
layout: post
title: "A Browser/Server-based Prototype of Heuristic Modelling Environment for Digital Terrain Analysis"
date: "2021-07-21"
tags: 
  - "awards"
permalink: /awards/qin2013/
---

<table><tbody><tr>
<td>Title</td>
<td>A Browser/Server-based Prototype of Heuristic Modelling Environment for Digital Terrain Analysis</td></tr><tr>
<td>Publication Type</td>
<td>Conference Paper</td></tr><tr>
<td>Year of Publication</td>
<td>2013</td></tr><tr>
<td>Authors</td>
<td>Qin, Cheng-Zhi,&nbsp;Jing-Chao Jiang,&nbsp;Li-Jun Zhan,&nbsp;Yan-Jun Lu, and&nbsp;Zhu A-Xing</td></tr><tr>
<td>Refereed Designation</td>
<td>Refereed</td></tr><tr>
<td>Conference Name</td>
<td>Geomorphometry 2013</td></tr><tr>
<td>Date Published</td>
<td>2013</td></tr><tr>
<td>Conference Location</td>
<td>Nanjing, China</td></tr><tr>
<td>Abstract</td>
<td>To narrow the “digital divide” in Digital Terrain Analysis (DTA) modelling and application, we proposed a Browser/Server (B/S)-based prototype of heuristic DTA modelling environment. In this prototype, formalized DTA knowledge was used to support heuristic and visualized modelling of user’s application-specific DTA workflow. B/S structure can provide DTA users with high accessibility to DTA algorithms. Parallel DTA algorithms of computing not only local topographic attributes but also regional topographic attributes were implemented based on Message Passing Interface (MPI) to speed up the execution time of user-built DTA workflow. A case study of calculating topographic wetness index (TWI) for a low-relief catchment at fine resolution shows that employing the proposed DTA modelling environment, user can build an application-specific TWI-calculating workflow for his/her application context in a much easier way than existing DTA-assisted tools. There is less requirement of user’s DTA knowledge during the modelling process. The TWI-calculating workflow can get reasonable TWI result when the execution time of the workflow was distinctly speeded up.</td></tr></tbody></table>

* * *

**_Attachment:_**

[Download](/uploads/pdf/pdf2013/Qin2013geomorphometry.pdf)
