---
layout: post
title: "Physiographic Classification of the Ocean Floor: A Multi-Scale Geomorphometric Approach"
date: "2021-07-21"
tags: 
  - "awards"
  - "global-scale-geomorphometry"
permalink: /awards/gorini2009/
---

M. A. V. Gorini  
Departamento de Geologia - LAGEMAR /UFF  
Av. General Milton Tavares de Souza, 4º andar, Niterói - RJ  
CEP24210-346 - Brasil  
Telephone: 55 (21) 2629-5930  
Fax: 55 (21) 2629-5931  
Email: gorini@gmail.com

Physiography, in this paper, is the study and classification of the surface features of Earth. In the oceanic domain, the Physiographic Diagram of the North Atlantic by Heezen et al. (1959) forged our knowledge of the actual form of the ocean basins. Since then, much has been published about the morphology of continental margins, the geology of oceanic trenches and the continuity of the mid-oceanic ridge. In most of these studies, however, the pioneer work of Bruce Heezen and his colleagues proved to be precise, despite being grounded upon sparsely collected data and a lot of “scientific imagination”.

Presently, the increasing availability of high-resolution and/or globally distributed Digital Elevation Models (DEMs), together with innumerous improvements in geomorphometry – the quantitative analysis of topography – stimulates objective classifications of the physiography of landscapes. In particular, the Smith and Sandwell (1997) global digital bathymetric database represents an invaluable contribution to ocean floor mapping. However, while classifications of topography of continental landscapes (Dikau et al. 1991, Brabyn 1997, Iwahashi and Pike 2007), or even of planetary landscapes (Miliaresis and Kokkas 2003, Stepinski and Bagaria 2009) are becoming common subjects of geomorphometry, submarine environments are rarely investigated through quantitative geomorphological techniques (Micallef et al. 2007), especially at physiographic scales. Also, the basic problem in geomorphometry – the fact that all measures vary with the scale of analysis (Evans 1972) - is seldom considered in submarine mapping efforts.

Therefore, the intention of this paper is to develop and test a geomorphometric classification procedure to be applied to the global Smith and Sandwell (1997) database. The geometric signature concept - “a set of measures that describes the topographic form well enough to distinguish among topographically disparate landscapes” (Pike 1988) - will be used to describe the ocean floor in a multi-scale approach and to classify topography in distinct physiographic domains. The main idea is to evaluate if there can be a “recipe” for the automated identification of physiographic provinces and how such classification correlates with the established knowledge.

* * *

**_Attachment:_**

[Download](/uploads/pdf/pdf2009/gorini2009geomorphometry.pdf)
