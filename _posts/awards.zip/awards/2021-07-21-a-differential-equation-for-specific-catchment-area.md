---
layout: post
title: "A Differential Equation for Specific Catchment Area"
date: "2021-07-21"
tags: 
  - "awards"
  - "methodological-developments"
permalink: /awards/gallant2009/
---

J. C. Gallant1, M. F. Hutchinson2  
1 CSIRO Land and Water, GPO Box 1666, Canberra ACT 2601, Australia  
Telephone: +61 2 62465734  
Fax: +61 2 62465800  
Email: [John.Gallant@csiro.au](mailto:John.Gallant@csiro.au)  
2 Fenner School of Environment and Society, Australian National University, Canberra ACT 0200, Australia  
Telephone: +61 2 61254783  
Fax: +61 2 61250757  
Email: Michael.Hutchinson@anu.edu.au

Specific catchment area is one of the key land-surface parameters used in the fields of hydrology, geomorphology, pedology and ecology and many methods have been devised to estimate it from grid DLSMs. An accurate reference is required to test these methods, but specific catchment area has only been determined analytically for simple surfaces such as inclined planes and cones. To assess the results on the complex surfaces of natural terrain developers and users have resorted to comparisons between the results from different methods and visual inspection of the patterns of estimated specific catchment area. This paper presents a differential equation that describes the rate of change of specific catchment area along a flow line. The equation can be solved numerically along a flow line that is derived numerically from a grid digital elevation model, allowing precise values of specific catchment area to be obtained at any location on a complex terrain surface. The development of the concepts and exploration of the results and implications are addressed in more detail in Gallant and Hutchinson, (in preparation).

* * *

**_Attachment:_**

[Download](/uploads/pdf/pdf2009/gallanta2009geomorphometry.pdf)
