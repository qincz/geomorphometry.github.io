---
layout: post
title: "Mapping gradient fields of landform migration"
date: "2021-07-21"
tags: 
  - "awards"
permalink: /awards/petras2015/
---

<table class="has-fixed-layout"><tbody><tr>
<td>Title</td>
<td>Mapping gradient fields of landform migration</td></tr><tr>
<td>Publication Type</td>
<td>Book Chapter</td></tr><tr>
<td>Year of Publication</td>
<td>2015</td></tr><tr>
<td>Authors</td>
<td>Petras, Vaclav,&nbsp;Helena Mitasova, and&nbsp;Anna Petrasova</td></tr><tr>
<td>Secondary Authors</td>
<td>Jasiewicz, Jaroslaw,&nbsp;Zbigniew Zwoliński,&nbsp;Helena Mitasova, and&nbsp;Tomislav Hengl</td></tr><tr>
<td>Book Title</td>
<td>Geomorphometry for Geosciences</td></tr><tr>
<td>Pagination</td>
<td>173 - 176</td></tr><tr>
<td>Publisher</td>
<td>Bogucki Wydawnictwo Naukowe, Adam Mickiewicz University in Poznań - Institute of Geoecology and Geoinformation</td></tr><tr>
<td>City</td>
<td>Poznań, Poland</td></tr><tr>
<td>ISBN Number</td>
<td>978-83-7986-059-3</td></tr><tr>
<td>Abstract</td>
<td>Geospatial analytics techniques describing changes of unstable landscapes provide critical information for hazard man- agement and mitigation. We propose a method for quantifying horizontal migration of complex landforms based on the analysis of contour evolution. When applied to a set of elevations this technique provides comprehensive information on magnitude and direction of landform migration at any point in space and time. The method is based on the concept of space-time cube combined with GIS- based analysis applied to spatio-temporal surface. The result of the analysis is a vector ﬁeld representing the movement and deformation of contours. We also present several approaches to visualization of these vector ﬁelds as space-time gradient lines, vectors or dynamic ”comets”. We demonstrate the method on a laboratory model and an elevation time series capturing evolution of a coastal sand dune.</td></tr></tbody></table>

* * *

**_Attachment:_**

[Download](/uploads/pdf/pdf2015/Petras2015geomorphometry.pdf)
