---
layout: post
title: "Geomorphons - a new approach to classification of landforms"
date: "2021-07-21"
tags: 
  - "awards"
permalink: /awards/stepinski2011/
---

<table><tbody><tr>
<td>Title</td>
<td>Geomorphons - a new approach to classification of landforms</td></tr><tr>
<td>Publication Type</td>
<td>Conference Paper</td></tr><tr>
<td>Year of Publication</td>
<td>2011</td></tr><tr>
<td>Authors</td>
<td>Stepinski, T., and&nbsp;J. Jasiewicz</td></tr><tr>
<td>Refereed Designation</td>
<td>Refereed</td></tr><tr>
<td>Secondary Authors</td>
<td>Hengl, T.,&nbsp;I. &nbsp;S. Evans,&nbsp;J. &nbsp;P. Wilson, and&nbsp;M. Gould</td></tr><tr>
<td>Conference Name</td>
<td>Geomorphometry 2011</td></tr><tr>
<td>Conference Location</td>
<td>Redlands, CA</td></tr><tr>
<td>Abstract</td>
<td>We introduce a novel method for classification and mapping of landforms based on the idea that the Earth’s surface can be described by the two complementary measures: relief-independent, local spatial pattern and the magnitude of the relief itself. The first of these two measures is sufficient to classify and map the landforms. At the core of the method is the concept of geomorphon (geomorphologic phonotype). A geomorphon is a relief-invariant, orientation-invariant, and size-flexible abstracted elementary unit of terrain. It is expressed in terms of local ternary pattern that encapsulates morphology of surface around the point of interest. Geomorphons enable terrain analysis without resorting to differential geometry. A collection of 498 different geomorphons constitutes a comprehensive and exhaustive set of all possible morphological terrain types. This set includes both standard elements of the landscape, as well as unfamiliar forms rarely found on natural terrestrial surfaces. Geomorphons are both terrain attributes and landform types. This reduces the task of landform mapping to the identification of geomorphons by their labels across the site of interest. We describe the fundamental ideas behind the geomorphon concept. We also give an example of how a map of a standard landform types can be constructed using geomorphons.</td></tr></tbody></table>

* * *

**_Attachment:_**

[Download](/uploads/pdf/pdf2011/StepinskiJasiewicz2011geomorphometry.pdf)
