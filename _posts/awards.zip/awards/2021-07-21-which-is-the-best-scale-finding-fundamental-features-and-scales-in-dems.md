---
layout: post
title: "Which is the best scale? Finding fundamental features and scales in DEMs"
date: "2021-07-21"
tags: 
  - "awards"
permalink: /awards/gorini2011/
---

<table><tbody><tr>
<td>Title</td>
<td>Which is the best scale? Finding fundamental features and scales in DEMs</td></tr><tr>
<td>Publication Type</td>
<td>Conference Paper</td></tr><tr>
<td>Year of Publication</td>
<td>2011</td></tr><tr>
<td>Authors</td>
<td>Gorini, M. &nbsp;A. &nbsp;V., and&nbsp;G. &nbsp;L. Abelha Mota</td></tr><tr>
<td>Secondary Authors</td>
<td>Hengl, T.,&nbsp;I. &nbsp;S. Evans,&nbsp;J. &nbsp;P. Wilson, and&nbsp;M. Gould</td></tr><tr>
<td>Conference Name</td>
<td>Geomorphometry 2011</td></tr><tr>
<td>Conference Location</td>
<td>Redlands, CA</td></tr><tr>
<td>Abstract</td>
<td>A method is presented to explicitly incorporate scale in geomorphometric analyses. It is based on Wood's 1996 method for morphometric feature extraction, but enhances it by fuzzifying its extraction function, automatically parameterizing it and locally limiting the maximum scale of analysis. As a result, maps of fundamental features and scales are produced, which describe well the overall topography of DEMs, as well as its multi-scale nature. The method was applied to diverse DEMs and compared to fixed-scale and modal feature approaches. Multi-scale geomorphometric variables were also produced and evaluated. The results suggest that the method allows thorough unsupervised geomorphometric characterizations of DEMs, stimulating further research.</td></tr></tbody></table>

* * *

**_Attachment:_**

[Download](/uploads/pdf/pdf2011/GoriniMota2011geomorphometry.pdf)
