---
layout: post
title: "An Ocean of Possibilities: Applications and Challenges of Marine Geomorphometry"
date: "2021-07-21"
tags: 
  - "awards"
permalink: /awards/lecours2015/
---

<table><tbody><tr>
<td>Title</td>
<td>An Ocean of Possibilities: Applications and Challenges of Marine Geomorphometry</td></tr><tr>
<td>Publication Type</td>
<td>Book Chapter</td></tr><tr>
<td>Year of Publication</td>
<td>2015</td></tr><tr>
<td>Authors</td>
<td>Lecours, Vincent,&nbsp;Vanessa Lucieer,&nbsp;Margaret Dolan, and&nbsp;Aaron Micallef</td></tr><tr>
<td>Secondary Authors</td>
<td>Jasiewicz, Jaroslaw,&nbsp;Zbigniew Zwoliński,&nbsp;Helena Mitasova, and&nbsp;Tomislav Hengl</td></tr><tr>
<td>Book Title</td>
<td>Geomorphometry for Geosciences</td></tr><tr>
<td>Pagination</td>
<td>23 - 26</td></tr><tr>
<td>Publisher</td>
<td>Bogucki Wydawnictwo Naukowe, Adam Mickiewicz University in Poznań - Institute of Geoecology and Geoinformation</td></tr><tr>
<td>City</td>
<td>Poznań, Poland</td></tr><tr>
<td>ISBN Number</td>
<td>978-83-7986-059-3</td></tr><tr>
<td>Abstract</td>
<td>An increase in the use of geomorphometry in the marine environment has occurred in the last decade. This has been fueled by a dramatic increase in digital bathymetric data, which have become widely available as digital terrain models (DTM) at a variety of spatial resolutions. Despite many similarities, the nature of the input DTM is slightly different than terrestrial DTM. This gives rise to different sources of uncertainties in bathymetric data from various sources that will have particular implications for geomorphometric analysis. With this contribution, we aim to raise awareness of applications and challenges of marine geomorphometry.</td></tr></tbody></table>

* * *

**_Attachment:_**

[Download](/uploads/pdf/pdf2015/LecoursLucieer2015geomorphometry.pdf)
