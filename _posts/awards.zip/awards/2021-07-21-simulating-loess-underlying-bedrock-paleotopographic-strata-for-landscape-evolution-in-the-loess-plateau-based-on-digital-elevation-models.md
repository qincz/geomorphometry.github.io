---
layout: post
title: "Simulating Loess Underlying Bedrock Paleotopographic strata for Landscape Evolution in the Loess Plateau Based on Digital Elevation Models"
date: "2021-07-21"
tags: 
  - "awards"
permalink: /awards/xiong2013/
---

<table><tbody><tr>
<td>Title</td>
<td>Simulating Loess Underlying Bedrock Paleotopographic strata for Landscape Evolution in the Loess Plateau Based on Digital Elevation Models</td></tr><tr>
<td>Publication Type</td>
<td>Conference Paper</td></tr><tr>
<td>Year of Publication</td>
<td>2013</td></tr><tr>
<td>Authors</td>
<td>Xiong, Liyang, and&nbsp;G. Tang</td></tr><tr>
<td>Refereed Designation</td>
<td>Refereed</td></tr><tr>
<td>Conference Name</td>
<td>Geomorphometry 2013</td></tr><tr>
<td>Date Published</td>
<td>2013</td></tr><tr>
<td>Conference Location</td>
<td>Nanjing, China</td></tr><tr>
<td>Abstract</td>
<td>The evolution processes of loess landforms are greatly controlled by the pre-quaternary underlying bedrock terrain, which is one of the most important aspects to explain the formation mechanism of loess landform. In this research, on the basis of multiple data sources, 1729 outcropping points of underlying terrain are detected to construct a simulated digital elevation model of the pre-quaternary underlying paleotography in a severe soil erosion area of Loess Plateau. The results show that obvious differences could be found between the underlying terrain and modern terrain, the topographic complexity of the underlying terrain appears simpler than that of the modern terrain. In addition, the modern surface gentles the topographic relief of the underlying terrain, as well as shows a signifacant landform inheritance characteristic of loess deposition. All these results deepen the understanding of the formation and evolution of loess landform.</td></tr></tbody></table>

* * *

**_Attachment:_**

[Download](/uploads/pdf/pdf2013/XiongTang2013geomorphometry.pdf)
