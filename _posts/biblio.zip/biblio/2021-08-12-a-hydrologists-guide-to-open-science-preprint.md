---
layout: post
tags: [biblio,paper]
title: "A Hydrologist's Guide to Open Science (preprint)"
date: "2021-08-12"
categories: 
  - "publication"
  - "story"
coverImage: "open_hydrology_principles.png"
---

Hall et al., (2021) have recently submitted a paper discussing a general Open Hydrology framework to guide individual and community progress toward open science for research and education. In the times when reproducible research and Open Science are more important than ever, this seems as a systematic guide that everyone (beyond hydrologists!) should read:

- Hall, C. A., Saia, S. M., Popp, A. L., Dogulu, N., Schymanski, S. J., Drost, N., van Emmerik, T., and Hut, R.: **[A Hydrologist's Guide to Open Science](https://doi.org/10.5194/hess-2021-392)**, Hydrol. Earth Syst. Sci. Discuss. \[preprint\], https://doi.org/10.5194/hess-2021-392, in review, 2021.
