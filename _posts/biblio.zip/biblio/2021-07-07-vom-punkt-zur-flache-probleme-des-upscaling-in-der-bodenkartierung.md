---
layout: post
tags: [biblio,paper]
title: "Vom Punkt zur Flache – Probleme des \"upscaling\" in der Bodenkartierung"
date: "2021-07-07"
---

<table><tbody><tr><td>Title</td><td>Vom Punkt zur Flache – Probleme des "upscaling" in der Bodenkartierung</td></tr><tr><td>Publication Type</td><td>Book Chapter</td></tr><tr><td>Year of Publication</td><td>2001</td></tr><tr><td>Authors</td><td>Gehrt, E., and&nbsp;J. Böhner</td></tr><tr><td>Book Title</td><td>Diskussionsforum Bodenwissenschaften: Vom Bohrstock zum Bildschirm</td></tr><tr><td>Pagination</td><td>17-34</td></tr><tr><td>Publisher</td><td>FH</td></tr><tr><td>City</td><td>Osnabrück</td></tr></tbody></table>
