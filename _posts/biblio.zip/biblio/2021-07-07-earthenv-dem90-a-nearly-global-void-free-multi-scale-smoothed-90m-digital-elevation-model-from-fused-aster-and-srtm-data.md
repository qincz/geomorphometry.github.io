---
layout: post
tags: [biblio,paper]
title: "EarthEnv-DEM90: A nearly-global, void-free, multi-scale smoothed, 90m digital elevation model from fused ASTER and SRTM data"
date: "2021-07-07"
---

<table><tbody><tr><td>Title</td><td>EarthEnv-DEM90: A nearly-global, void-free, multi-scale smoothed, 90m digital elevation model from fused ASTER and SRTM data</td></tr><tr><td>Publication Type</td><td>Journal Article</td></tr><tr><td>Year of Publication</td><td>2014</td></tr><tr><td>Authors</td><td>Robinson, Natalie,&nbsp;James Regetz, and&nbsp;Robert P. Guralnick</td></tr><tr><td>Journal</td><td>İSPRS Journal of Photogrammetry and Remote Sensing</td></tr><tr><td>Volume</td><td>87</td></tr><tr><td>Pagination</td><td>57 - 67</td></tr><tr><td>ISSN</td><td>0924-2716</td></tr><tr><td>Keywords</td><td>DEM blending</td></tr><tr><td>URL</td><td><a href="http://www.sciencedirect.com/science/article/pii/S0924271613002360">http://www.sciencedirect.com/science/article/pii/S0924271613002360</a></td></tr><tr><td>DOI</td><td><a href="http://dx.doi.org/10.1016/j.isprsjprs.2013.11.002">http://dx.doi.org/10.1016/j.isprsjprs.2013.11.002</a></td></tr></tbody></table>
