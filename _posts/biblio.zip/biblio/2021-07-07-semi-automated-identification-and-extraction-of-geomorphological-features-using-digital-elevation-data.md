---
layout: post
tags: [biblio,paper]
title: "Semi-automated identification and extraction of geomorphological features using digital elevation data"
date: "2021-07-07"
---

<table><tbody><tr><td>Title</td><td>{Semi-automated identification and extraction of geomorphological features using digital elevation data}</td></tr><tr><td>Publication Type</td><td>Book Chapter</td></tr><tr><td>Year of Publication</td><td>2011</td></tr><tr><td>Authors</td><td>Seijmonsbergen, A. C.,&nbsp;T. Hengl, and&nbsp;N. S. Anders</td></tr><tr><td>Secondary Authors</td><td>Smith, M. J.,&nbsp;P. Paron, and&nbsp;J. Griffiths</td></tr><tr><td>Book Title</td><td>{Geomorphological Mapping: a professional handbook of techniques and applications}</td></tr><tr><td>Series Title</td><td>Developments in Earth Surface Processes</td></tr><tr><td>Pagination</td><td>24</td></tr><tr><td>Publisher</td><td>Elsevier</td></tr><tr><td>City</td><td>Amsterdam</td></tr><tr><td>URL</td><td><a href="http://researchbooks.org/0444534466">http://researchbooks.org/0444534466</a></td></tr></tbody></table>
